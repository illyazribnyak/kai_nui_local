#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
🧠 AI Manager — DeepSeek (наратив) + Gemini (аналітика)
"""
import os
import json
import re
import requests
import time
from pathlib import Path

BASE_DIR = Path(__file__).parent

# Налаштування
DEEPSEEK_URL = "https://api.deepseek.com/v1/chat/completions"
DEEPSEEK_MODEL = "deepseek-chat"
GEMINI_URL_TPL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
GEMINI_MODEL = "gemini-2.0-flash"

MAX_CONTEXT_MESSAGES = 30
COMPRESS_THRESHOLD = 40

# Ціни за 1M токенів (USD)
PRICING = {
    'deepseek-chat': {'input': 0.27, 'output': 1.10},
    'gemini-2.0-flash': {'input': 0.075, 'output': 0.30},
}

def get_api_keys():
    """Get API keys from env"""
    return {
        'deepseek': os.environ.get('DEEPSEEK_API_KEY', ''),
        'gemini': os.environ.get('GEMINI_API_KEY', ''),
    }

def calc_cost(model, input_tokens, output_tokens):
    """Calculate cost in USD"""
    p = PRICING.get(model, {'input': 0.5, 'output': 1.0})
    return (input_tokens * p['input'] + output_tokens * p['output']) / 1_000_000

# ============================================================
# DEEPSEEK — Основний наратор
# ============================================================

def deepseek_stream(system_prompt, messages, api_key):
    """
    Stream response from DeepSeek. Yields chunks.
    Returns (full_text, usage_dict) via .result attribute after iteration.
    """
    api_messages = [{"role": "system", "content": system_prompt}]
    for m in messages:
        api_messages.append({"role": m['role'], "content": m['content']})

    try:
        resp = requests.post(DEEPSEEK_URL, headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }, json={
            "model": DEEPSEEK_MODEL,
            "messages": api_messages,
            "stream": True,
            "temperature": 0.85,
            "max_tokens": 4000,
            "top_p": 0.95
        }, stream=True, timeout=120)

        if resp.status_code != 200:
            error_msg = f"Помилка DeepSeek: {resp.status_code}"
            try:
                ed = resp.json()
                error_msg += f" — {ed.get('error',{}).get('message','')}"
            except:
                pass
            yield {'error': error_msg}
            return

        full_text = ""
        for line in resp.iter_lines():
            if not line:
                continue
            ls = line.decode('utf-8').strip()
            if ls.startswith('data: '):
                ds = ls[6:]
                if ds == '[DONE]':
                    break
                try:
                    chunk = json.loads(ds)
                    content = chunk.get('choices',[{}])[0].get('delta',{}).get('content','')
                    if content:
                        full_text += content
                        yield {'content': content}
                except:
                    pass

        # Оцінка токенів (приблизно)
        input_est = len(system_prompt + str(messages)) // 4
        output_est = len(full_text) // 4
        cost = calc_cost(DEEPSEEK_MODEL, input_est, output_est)
        yield {'done': True, 'full_text': full_text,
               'usage': {'model': DEEPSEEK_MODEL, 'input': input_est, 'output': output_est, 'cost': cost}}

    except requests.exceptions.Timeout:
        yield {'error': 'Тайм-аут DeepSeek API'}
    except Exception as e:
        yield {'error': f'Помилка DeepSeek: {str(e)}'}

# ============================================================
# GEMINI — Фоновий аналітик
# ============================================================

def gemini_call(prompt, system_instruction="", api_key="", max_tokens=2000, temperature=0.4):
    """
    Single call to Gemini API. Returns (text, usage_dict) or (None, error_str)
    """
    if not api_key:
        return None, "Немає Gemini API ключа"

    url = GEMINI_URL_TPL.format(model=GEMINI_MODEL, key=api_key)
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "maxOutputTokens": max_tokens,
            "temperature": temperature
        }
    }
    if system_instruction:
        body["systemInstruction"] = {"parts": [{"text": system_instruction}]}

    try:
        resp = requests.post(url, json=body, timeout=60)
        if resp.status_code != 200:
            return None, f"Gemini {resp.status_code}: {resp.text[:200]}"
        data = resp.json()
        text = data['candidates'][0]['content']['parts'][0]['text']
        usage_meta = data.get('usageMetadata', {})
        input_t = usage_meta.get('promptTokenCount', 0)
        output_t = usage_meta.get('candidatesTokenCount', 0)
        cost = calc_cost(GEMINI_MODEL, input_t, output_t)
        usage = {'model': GEMINI_MODEL, 'input': input_t, 'output': output_t, 'cost': cost}
        return text, usage
    except Exception as e:
        return None, f"Gemini помилка: {str(e)}"

# ============================================================
# ГЕМІНІ ЗАДАЧІ (BACKGROUND)
# ============================================================

def gemini_analyze_turn(ai_response, game_state, api_key):
    """
    Gemini аналізує відповідь DeepSeek і повертає JSON з оновленнями:
    - quests, inventory, skills, lore, achievements, body_evolution,
      rumors, tribe_reputation, companion, mood_updates, amulet_warning
    """
    prompt = f"""Проаналізуй цю ігрову відповідь і поверни JSON з оновленнями.

ПОТОЧНИЙ СТАН:
- Локація: {game_state.get('location','')}
- День: {game_state.get('current_day',1)}
- Час доби: {game_state.get('time_of_day','')}

ВІДПОВІДЬ AI:
{ai_response[:3000]}

Поверни ТІЛЬКИ валідний JSON (без markdown обгортки) з такими полями (порожні масиви якщо немає змін):
{{
  "quests": [{{"title": "", "status": "active/completed/failed", "progress": "", "description": "", "giver": ""}}],
  "inventory_add": [{{"name": "", "type": "weapon/food/artifact/medicine/misc", "quantity": 1, "description": ""}}],
  "inventory_remove": [{{"name": "", "quantity": 1}}],
  "skills_exp": [{{"name": "Бій/Виживання/Красномовство/Скритність/Алхімія/Магія/Зваблення", "exp": 10}}],
  "lore": [{{"category": "tribe/creature/location/artifact/magic", "title": "", "content": ""}}],
  "achievements": ["назва досягнення"],
  "body_changes": [{{"body_part": "", "change_type": "", "description": "", "source": ""}}],
  "rumors": [{{"content": "", "source_tribe": "", "target": ""}}],
  "tribe_rep_changes": [{{"tribe": "", "change": 0, "reason": ""}}],
  "companion_update": {{"name": "", "mood": "", "bond_change": 0}},
  "mood_updates": [{{"name": "ім'я NPC", "mood": "радісний/злий/сумний/збуджений/підозрілий/нейтральний"}}],
  "amulet_warning": "",
  "discovered_locations": ["назва локації"]
}}"""

    system = "Ти — аналітик текстової RPG гри. Аналізуй відповіді Гейм-Майстра та витягуй зміни ігрового стану. Відповідай ТІЛЬКИ валідним JSON."
    text, usage = gemini_call(prompt, system, api_key, max_tokens=1500)
    if text:
        # Очистити від markdown
        clean = text.strip()
        if clean.startswith('```'):
            clean = re.sub(r'^```\w*\n?', '', clean)
            clean = re.sub(r'\n?```$', '', clean)
        try:
            return json.loads(clean), usage
        except:
            return None, usage
    return None, usage

def gemini_generate_random_event(game_state, tribe_reps, api_key):
    """Gemini генерує рандомну подію"""
    reps_str = ", ".join([f"{t['tribe_name']}: {t['reputation']}" for t in tribe_reps])
    prompt = f"""Створи рандомну подію для текстової RPG.

Локація: {game_state.get('location','')}
Час доби: {game_state.get('time_of_day','')}
День: {game_state.get('current_day',1)}
Здоров'я: {game_state.get('health',100)}/100
Бажання: {game_state.get('desire',0)}/100
Репутація племен: {reps_str}

Поверни JSON (без markdown):
{{"event": "короткий опис події українською", "type": "encounter/discovery/weather/danger/social", "danger": 1-10}}"""

    text, usage = gemini_call(prompt, "Ти генератор подій для RPG. Відповідай ТІЛЬКИ JSON.",
                              api_key, max_tokens=300, temperature=0.9)
    if text:
        clean = text.strip()
        if clean.startswith('```'):
            clean = re.sub(r'^```\w*\n?', '', clean)
            clean = re.sub(r'\n?```$', '', clean)
        try:
            return json.loads(clean), usage
        except:
            pass
    return None, usage

def gemini_generate_diary(day_events_summary, game_state, api_key):
    """Генерація запису щоденника від першої особи Лари"""
    prompt = f"""Напиши запис у щоденнику Лари Крофт за день {game_state.get('current_day',1)}.
Пиши від першої особи, українською, емоційно та особисто. 150-250 слів.
Лара — археолог на магічному острові з племенами людей і нелюдів.

Події дня:
{day_events_summary}

Стан Лари: здоров'я {game_state.get('health',100)}, бажання {game_state.get('desire',0)}, сором {game_state.get('shame',70)}, впевненість {game_state.get('confidence',30)}"""

    text, usage = gemini_call(prompt, "Ти пишеш щоденник персонажа RPG гри. Пиши українською, емоційно, від першої особи.",
                              api_key, max_tokens=600, temperature=0.7)
    return text, usage

def gemini_generate_dream(game_state, recent_events, api_key):
    """Генерація сну Лари"""
    prompt = f"""Створи сон Лари Крофт на магічному острові.
Пиши українською, сюрреалістично, 100-200 слів.

Останні події: {recent_events}
Бажання: {game_state.get('desire',0)}/100
Енергія амулета: {game_state.get('amulet_energy',100)}/100

Поверни JSON (без markdown):
{{"dream_type": "prophetic/erotic/nightmare/magical", "content": "опис сну", "effects": "вплив на стан"}}"""

    text, usage = gemini_call(prompt, "Ти генеруєш сни для RPG персонажа. Відповідай JSON.",
                              api_key, max_tokens=500, temperature=0.9)
    if text:
        clean = text.strip()
        if clean.startswith('```'):
            clean = re.sub(r'^```\w*\n?', '', clean)
            clean = re.sub(r'\n?```$', '', clean)
        try:
            return json.loads(clean), usage
        except:
            pass
    return None, usage

def gemini_generate_travel_event(from_loc, to_loc, game_state, api_key):
    """Подія під час подорожі"""
    prompt = f"""Героїня подорожує з "{from_loc}" до "{to_loc}" на магічному острові.
Час доби: {game_state.get('time_of_day','')}

What happens during the journey? Create a brief travel event in Ukrainian.

Поверни JSON (без markdown):
{{"event": "короткий опис українською", "type": "peaceful/encounter/danger/discovery", "has_interaction": true/false}}"""

    text, usage = gemini_call(prompt, "Генеруй короткі подорожні події для RPG. ТІЛЬКИ JSON.",
                              api_key, max_tokens=300, temperature=0.8)
    if text:
        clean = text.strip()
        if clean.startswith('```'):
            clean = re.sub(r'^```\w*\n?', '', clean)
            clean = re.sub(r'\n?```$', '', clean)
        try:
            return json.loads(clean), usage
        except:
            pass
    return None, usage

def gemini_generate_dialog_options(context, npc_name, npc_mood, game_state, api_key):
    """Генерація варіантів діалогу"""
    prompt = f"""Героїня розмовляє з {npc_name} (настрій: {npc_mood}).
Контекст: {context[:500]}
Харизма Лари: {game_state.get('charisma',6)}/10
Впевненість: {game_state.get('confidence',30)}/100

Створи 4-5 варіантів реплік українською. Поверни JSON (без markdown):
[{{"tone": "дружній/агресивний/флірт/хитрість/відмова", "text": "репліка", "icon": "😊/😠/😏/🤔/✋"}}]"""

    text, usage = gemini_call(prompt, "Генеруй варіанти діалогу для RPG. ТІЛЬКИ JSON масив.",
                              api_key, max_tokens=500, temperature=0.7)
    if text:
        clean = text.strip()
        if clean.startswith('```'):
            clean = re.sub(r'^```\w*\n?', '', clean)
            clean = re.sub(r'\n?```$', '', clean)
        try:
            return json.loads(clean), usage
        except:
            pass
    return None, usage

def gemini_compress_memory(messages_text, api_key):
    """Стиснення старої історії в підсумок"""
    prompt = f"""Стисни цю частину ігрової історії в короткий підсумок (300-500 слів) українською.
Збережи: ключові події, імена, зміни стосунків, сексуальні події, предмети, локації.

{messages_text}"""

    text, usage = gemini_call(prompt, "Ти стискаєш ігрову історію. Пиши українською.",
                              api_key, max_tokens=1000, temperature=0.3)
    return text, usage

# ============================================================
# ПАРСИНГ ВІДПОВІДЕЙ DEEPSEEK
# ============================================================

def parse_deepseek_response(text):
    """Витягнути STAT_UPDATE та REL_UPDATE з відповіді"""
    stat_updates = {}
    rel_updates = []

    for m in re.findall(r'\[STAT_UPDATE\]\s*({[^}]+})\s*\[/STAT_UPDATE\]', text, re.DOTALL):
        try:
            stat_updates.update(json.loads(m))
        except:
            pass

    for m in re.findall(r'\[REL_UPDATE\]\s*({[^}]+})\s*\[/REL_UPDATE\]', text, re.DOTALL):
        try:
            rel_updates.append(json.loads(m))
        except:
            pass

    clean = re.sub(r'\[STAT_UPDATE\].*?\[/STAT_UPDATE\]', '', text, flags=re.DOTALL)
    clean = re.sub(r'\[REL_UPDATE\].*?\[/REL_UPDATE\]', '', clean, flags=re.DOTALL)
    clean = clean.strip()

    return clean, stat_updates, rel_updates
