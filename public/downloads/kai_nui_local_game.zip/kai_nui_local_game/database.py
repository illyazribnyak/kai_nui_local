#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
💾 База даних гри Острів Кай-Нуї
SQLite з усіма таблицями для ігрових систем
"""
import sqlite3
import json
import shutil
import os
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).parent
DB_PATH = BASE_DIR / "game.db"
BACKUP_DIR = BASE_DIR / "backups"

def get_db():
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def init_db():
    BACKUP_DIR.mkdir(exist_ok=True)
    conn = get_db()
    conn.executescript("""
        -- === ОСНОВНИЙ СТАН ГРИ ===
        CREATE TABLE IF NOT EXISTS game_state (
            id TEXT PRIMARY KEY DEFAULT 'main',
            -- Характеристики
            strength INTEGER DEFAULT 7,
            agility INTEGER DEFAULT 8,
            endurance INTEGER DEFAULT 7,
            charisma INTEGER DEFAULT 6,
            willpower INTEGER DEFAULT 8,
            -- Стан
            desire INTEGER DEFAULT 0,
            shame INTEGER DEFAULT 70,
            confidence INTEGER DEFAULT 30,
            -- Здоров'я / Виживання
            health INTEGER DEFAULT 100,
            max_health INTEGER DEFAULT 100,
            hunger INTEGER DEFAULT 100,
            thirst INTEGER DEFAULT 100,
            energy INTEGER DEFAULT 100,
            -- Локація та час
            location TEXT DEFAULT 'Пляж після аварії',
            time_of_day TEXT DEFAULT 'ранок',
            current_day INTEGER DEFAULT 1,
            -- Вагітність
            is_pregnant INTEGER DEFAULT 0,
            pregnancy_father TEXT DEFAULT '',
            pregnancy_day INTEGER DEFAULT 0,
            -- Амулет
            amulet_energy INTEGER DEFAULT 100,
            -- База / Табір
            home_location TEXT DEFAULT '',
            home_level INTEGER DEFAULT 0,
            -- Супутник
            companion_name TEXT DEFAULT '',
            companion_tribe TEXT DEFAULT '',
            -- Смерть
            is_dead INTEGER DEFAULT 0,
            death_reason TEXT DEFAULT '',
            -- Мета
            game_started INTEGER DEFAULT 0,
            total_messages INTEGER DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        );

        -- === ПОВІДОМЛЕННЯ ===
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TEXT DEFAULT (datetime('now'))
        );

        -- === СТОСУНКИ З NPC ===
        CREATE TABLE IF NOT EXISTS relationships (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            bond INTEGER DEFAULT 0,
            tribe TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            mood TEXT DEFAULT 'нейтральний',
            avatar TEXT DEFAULT '',
            met INTEGER DEFAULT 0
        );

        -- === РЕПУТАЦІЯ ПЛЕМЕН ===
        CREATE TABLE IF NOT EXISTS tribe_reputation (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tribe_name TEXT UNIQUE NOT NULL,
            reputation INTEGER DEFAULT 0,
            status TEXT DEFAULT 'невідомі',
            has_house INTEGER DEFAULT 0,
            house_level INTEGER DEFAULT 0,
            notes TEXT DEFAULT ''
        );

        -- === ІНВЕНТАР ===
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            item_type TEXT DEFAULT 'misc',
            quantity INTEGER DEFAULT 1,
            description TEXT DEFAULT '',
            effects TEXT DEFAULT '',
            equipped INTEGER DEFAULT 0
        );

        -- === ЖУРНАЛ КВЕСТІВ ===
        CREATE TABLE IF NOT EXISTS quests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT DEFAULT '',
            status TEXT DEFAULT 'active',
            progress TEXT DEFAULT '',
            giver TEXT DEFAULT '',
            reward TEXT DEFAULT '',
            created_day INTEGER DEFAULT 1,
            completed_day INTEGER DEFAULT 0
        );

        -- === НАВИЧКИ ===
        CREATE TABLE IF NOT EXISTS skills (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            level INTEGER DEFAULT 1,
            experience INTEGER DEFAULT 0,
            max_level INTEGER DEFAULT 10,
            category TEXT DEFAULT 'general',
            description TEXT DEFAULT ''
        );

        -- === ЩОДЕННИК ЛАРИ ===
        CREATE TABLE IF NOT EXISTS diary_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            day INTEGER NOT NULL,
            time_of_day TEXT DEFAULT '',
            content TEXT NOT NULL,
            mood TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now'))
        );

        -- === НОТАТКИ ГРАВЦЯ ===
        CREATE TABLE IF NOT EXISTS player_notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content TEXT NOT NULL,
            created_at TEXT DEFAULT (datetime('now'))
        );

        -- === БЕСТІАРІЙ / ЛОР ===
        CREATE TABLE IF NOT EXISTS lore_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT DEFAULT 'misc',
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            discovered_day INTEGER DEFAULT 1
        );

        -- === ДОСЯГНЕННЯ ===
        CREATE TABLE IF NOT EXISTS achievements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            description TEXT DEFAULT '',
            icon TEXT DEFAULT '🏆',
            unlocked INTEGER DEFAULT 0,
            unlocked_day INTEGER DEFAULT 0
        );

        -- === ЕВОЛЮЦІЯ ТІЛА ===
        CREATE TABLE IF NOT EXISTS body_evolution (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            body_part TEXT NOT NULL,
            change_type TEXT NOT NULL,
            description TEXT NOT NULL,
            source TEXT DEFAULT '',
            day_acquired INTEGER DEFAULT 1
        );

        -- === СУПУТНИКИ ===
        CREATE TABLE IF NOT EXISTS companions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            tribe TEXT DEFAULT '',
            bond INTEGER DEFAULT 0,
            mood TEXT DEFAULT 'нейтральний',
            abilities TEXT DEFAULT '',
            is_active INTEGER DEFAULT 0,
            avatar TEXT DEFAULT ''
        );

        -- === ЧУТКИ / ПЛІТКИ ===
        CREATE TABLE IF NOT EXISTS rumors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content TEXT NOT NULL,
            source_tribe TEXT DEFAULT '',
            target TEXT DEFAULT '',
            spread_day INTEGER DEFAULT 0,
            expires_day INTEGER DEFAULT 0,
            is_true INTEGER DEFAULT 1
        );

        -- === ПОДІЇ ЗА РОЗКЛАДОМ ===
        CREATE TABLE IF NOT EXISTS scheduled_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_name TEXT NOT NULL,
            description TEXT DEFAULT '',
            trigger_day INTEGER NOT NULL,
            trigger_time TEXT DEFAULT '',
            repeating INTEGER DEFAULT 0,
            repeat_interval INTEGER DEFAULT 0,
            completed INTEGER DEFAULT 0
        );

        -- === ПІДСУМКИ ПАМЯТІ ===
        CREATE TABLE IF NOT EXISTS story_summaries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            summary TEXT NOT NULL,
            messages_covered INTEGER DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now'))
        );

        -- === ЛОГУВАННЯ ТОКЕНІВ ===
        CREATE TABLE IF NOT EXISTS token_usage (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            model TEXT NOT NULL,
            input_tokens INTEGER DEFAULT 0,
            output_tokens INTEGER DEFAULT 0,
            cost_usd REAL DEFAULT 0.0,
            purpose TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now'))
        );

        -- === СЛОТИ ЗБЕРЕЖЕННЯ ===
        CREATE TABLE IF NOT EXISTS save_slots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            slot_name TEXT UNIQUE NOT NULL,
            full_dump TEXT NOT NULL,
            created_at TEXT DEFAULT (datetime('now'))
        );

        -- === КАРТА ЛОКАЦІЙ ===
        CREATE TABLE IF NOT EXISTS locations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            region TEXT DEFAULT '',
            description TEXT DEFAULT '',
            danger_level INTEGER DEFAULT 1,
            discovered INTEGER DEFAULT 0,
            connected_to TEXT DEFAULT '[]',
            travel_time TEXT DEFAULT '30 хв',
            available_resources TEXT DEFAULT '[]'
        );

        -- === ТОРГІВЛЯ ===
        CREATE TABLE IF NOT EXISTS trade_offers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tribe TEXT NOT NULL,
            offers_item TEXT NOT NULL,
            wants_item TEXT NOT NULL,
            quantity_offer INTEGER DEFAULT 1,
            quantity_want INTEGER DEFAULT 1,
            available INTEGER DEFAULT 1,
            expires_day INTEGER DEFAULT 0
        );

        -- === СНИ ===
        CREATE TABLE IF NOT EXISTS dreams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            day INTEGER NOT NULL,
            dream_type TEXT DEFAULT 'normal',
            content TEXT NOT NULL,
            effects TEXT DEFAULT ''
        );
    """)

    # Створити початковий стан
    if not conn.execute("SELECT id FROM game_state WHERE id='main'").fetchone():
        conn.execute("INSERT INTO game_state (id) VALUES ('main')")

    # Початкові навички
    default_skills = [
        ('Виживання', 'survival', 'Здатність знаходити їжу, воду, укриття'),
        ('Бій', 'combat', 'Майстерність в бою'),
        ('Красномовство', 'social', 'Вміння переконувати та чарувати'),
        ('Скритність', 'stealth', 'Тихе пересування та уникнення уваги'),
        ('Алхімія', 'craft', 'Створення зіль та знадіб'),
        ('Магія', 'magic', 'Використання магії амулета'),
        ('Зваблення', 'seduction', 'Мистецтво спокуси та інтимної взаємодії'),
        # === ДЕРЕВО СЕКСУАЛЬНИХ НАВИЧОК ===
        # Зваблення
        ('Чарівний погляд', 'sex_seduction', 'Вміння зачарувати поглядом'),
        ('Солодкі слова', 'sex_seduction', 'Мистецтво еротичних компліментів'),
        ('Спокусливий танець', 'sex_seduction', 'Танець, що розпалює бажання'),
        ('Аура бажання', 'sex_seduction', 'Магічна привабливість тіла'),
        # Техніка
        ('Ніжний дотик', 'sex_technique', 'Вміння ласкати тіло партнера'),
        ('Поцілунок вогню', 'sex_technique', 'Пристрасні поцілунки'),
        ('Гнучкість тіла', 'sex_technique', 'Різноманітні пози та рухи'),
        ('Майстерність рук', 'sex_technique', 'Вправність дотиків і ласк'),
        # Витривалість
        ('Тривала насолода', 'sex_endurance', 'Здатність довго тримати темп'),
        ('Множинне задоволення', 'sex_endurance', 'Кілька хвиль оргазму поспіль'),
        ('Контроль тіла', 'sex_endurance', 'Управління своїми відчуттями'),
        ('Невтомність', 'sex_endurance', 'Невичерпна сексуальна енергія'),
        # Домінування
        ('Владний голос', 'sex_domination', 'Командний тон, що збуджує'),
        ("Зв'язування", 'sex_domination', 'Мистецтво еротичного бондажу'),
        ('Покарання та нагорода', 'sex_domination', 'Гра з болем і насолодою'),
        ('Повна влада', 'sex_domination', 'Абсолютний контроль над партнером'),
        # Підкорення
        ('Покірність', 'sex_submission', 'Мистецтво віддаватися партнеру'),
        ('Чутливість', 'sex_submission', 'Підвищена чутливість до дотиків'),
        ('Прохання та благання', 'sex_submission', 'Вміння просити так, що неможливо відмовити'),
        ('Повна довіра', 'sex_submission', 'Абсолютна відкритість і вразливість'),
        # Магія тіла
        ('Цілюща ласка', 'sex_body_magic', 'Дотик, що зцілює тіло й душу'),
        ('Ритуал насолоди', 'sex_body_magic', 'Магічний ритуал через секс'),
        ("Зв'язок душ", 'sex_body_magic', "Телепатичний зв'язок під час близькості"),
        ('Екстаз сили', 'sex_body_magic', 'Перетворення оргазму на магічну енергію'),
    ]
    for name, cat, desc in default_skills:
        conn.execute("INSERT OR IGNORE INTO skills (name, category, description) VALUES (?, ?, ?)",
                     (name, cat, desc))

    # Початкові племена
    default_tribes = [
        ('Кай-Тору', 'нейтральні'),
        ('Центаври', 'невідомі'),
        ('Мінотаври', 'невідомі'),
        ('Свинолюди', 'невідомі'),
        ('Гієноїди', 'невідомі'),
    ]
    for name, status in default_tribes:
        conn.execute("INSERT OR IGNORE INTO tribe_reputation (tribe_name, status) VALUES (?, ?)",
                     (name, status))

    # Початкові локації
    default_locations = [
        ('Пляж після аварії', 'Берег', 'Піщаний пляж з уламками корабля', 1, 1, '["Узбережжя","Джунглі (вхід)"]', '0'),
        ('Узбережжя', 'Берег', 'Скелясте узбережжя з печерами', 2, 0, '["Пляж після аварії","Печера біля моря"]', '30 хв'),
        ('Печера біля моря', 'Берег', 'Темна печера в скелі', 3, 0, '["Узбережжя"]', '20 хв'),
        ('Джунглі (вхід)', 'Джунглі', 'Густі тропічні зарості', 3, 0, '["Пляж після аварії","Глибокі джунглі","Річка"]', '30 хв'),
        ('Глибокі джунглі', 'Джунглі', 'Непрохідні хащі з небезпеками', 5, 0, '["Джунглі (вхід)","Село Кай-Тору","Гірська стежка"]', '1 год'),
        ('Річка', 'Джунглі', 'Річка з прісною водою та водоспадом', 2, 0, '["Джунглі (вхід)","Водоспад"]', '45 хв'),
        ('Водоспад', 'Джунглі', 'Магічний водоспад з прихованою печерою', 3, 0, '["Річка"]', '30 хв'),
        ('Село Кай-Тору', 'Поселення', 'Головне село людського племені', 1, 0, '["Глибокі джунглі","Гірська стежка","Священний гай"]', '1 год'),
        ('Гірська стежка', 'Гори', 'Небезпечна стежка в гори', 6, 0, '["Глибокі джунглі","Село Кай-Тору","Територія Мінотаврів"]', '2 год'),
        ('Територія Мінотаврів', 'Гори', 'Гірське поселення мінотаврів', 7, 0, '["Гірська стежка","Храм Атлантів"]', '2 год'),
        ('Священний гай', 'Джунглі', 'Магічний ліс для ритуалів', 4, 0, '["Село Кай-Тору","Територія Центаврів"]', '1 год'),
        ('Територія Центаврів', 'Рівнини', 'Відкриті луки центаврів', 5, 0, '["Священний гай","Болота"]', '1.5 год'),
        ('Болота', 'Болота', 'Смердючі болота свинолюдів', 7, 0, '["Територія Центаврів","Територія Свинолюдів"]', '1 год'),
        ('Територія Свинолюдів', 'Болота', 'Поселення свинолюдів у болотах', 8, 0, '["Болота"]', '45 хв'),
        ('Територія Гієноїдів', 'Савана', 'Суха савана гієноїдів', 8, 0, '["Болота","Гірська стежка"]', '2 год'),
        ('Храм Атлантів', 'Гори', 'Стародавній храм в центрі острова', 10, 0, '["Територія Мінотаврів"]', '3 год'),
    ]
    for name, region, desc, danger, disc, connected, travel in default_locations:
        conn.execute("""INSERT OR IGNORE INTO locations (name, region, description, danger_level, discovered, connected_to, travel_time)
                        VALUES (?, ?, ?, ?, ?, ?, ?)""",
                     (name, region, desc, danger, disc, connected, travel))

    # Початкові заплановані події
    default_events = [
        ('Повний місяць', 'Ритуальна ніч — магія підсилена', 7, 'ніч', 1, 7),
        ('Ярмарок обміну', 'Племена торгують на нейтральній території', 10, 'день', 1, 10),
        ('Сезон полювання', 'Кай-Тору виходять на велике полювання', 14, 'ранок', 1, 14),
    ]
    for name, desc, day, time, rep, interval in default_events:
        existing = conn.execute("SELECT id FROM scheduled_events WHERE event_name=?", (name,)).fetchone()
        if not existing:
            conn.execute("""INSERT INTO scheduled_events (event_name, description, trigger_day, trigger_time, repeating, repeat_interval)
                            VALUES (?, ?, ?, ?, ?, ?)""", (name, desc, day, time, rep, interval))

    # Початкові досягнення
    default_achievements = [
        ('Перші кроки', 'Почати гру', '👣'),
        ('Перша кров', 'Перемогти в першому бою', '⚔️'),
        ('Дипломат', 'Досягти дружби з 3 племенами', '🤝'),
        ('Дослідниця', 'Відвідати 10 локацій', '🧭'),
        ('Серцеїдка', "Зв'язок 8+ з 3 NPC", '❤️'),
        ('Алхімік', 'Створити 10 зіль', '🧪'),
        ('Виживач', 'Прожити 30 днів', '🏕️'),
        ('Темний шлях', 'Вступити на шлях Темної Лари', '🌑'),
        ('Матір', 'Народити дитину', '👶'),
        ('Скарб Атлантів', 'Знайти легендарний артефакт', '📎'),
    ]
    for name, desc, icon in default_achievements:
        conn.execute("INSERT OR IGNORE INTO achievements (name, description, icon) VALUES (?, ?, ?)",
                     (name, desc, icon))

    conn.commit()
    conn.close()

# ============================================================
# CRUD ОПЕРАЦІЇ
# ============================================================

def get_game_state():
    conn = get_db()
    row = conn.execute("SELECT * FROM game_state WHERE id='main'").fetchone()
    conn.close()
    return dict(row) if row else None

def update_game_state(updates: dict):
    if not updates:
        return
    conn = get_db()
    valid = [c[1] for c in conn.execute("PRAGMA table_info(game_state)").fetchall()]
    sets, vals = [], []
    for k, v in updates.items():
        if k in valid and k != 'id':
            sets.append(f"{k}=?"); vals.append(v)
    if sets:
        sets.append("updated_at=datetime('now')")
        conn.execute(f"UPDATE game_state SET {','.join(sets)} WHERE id='main'", vals)
        conn.commit()
    conn.close()

def get_messages(limit=None):
    conn = get_db()
    if limit:
        rows = conn.execute("SELECT * FROM messages ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        rows = list(reversed(rows))
    else:
        rows = conn.execute("SELECT * FROM messages ORDER BY id ASC").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def add_message(role, content):
    conn = get_db()
    conn.execute("INSERT INTO messages (role, content) VALUES (?,?)", (role, content))
    conn.execute("UPDATE game_state SET total_messages=total_messages+1 WHERE id='main'")
    conn.commit()
    count = conn.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
    conn.close()
    return count

def get_message_count():
    conn = get_db()
    c = conn.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
    conn.close()
    return c

def delete_last_messages(n=2):
    """Undo: видалити останні n повідомлень"""
    conn = get_db()
    ids = conn.execute("SELECT id FROM messages ORDER BY id DESC LIMIT ?", (n,)).fetchall()
    for row in ids:
        conn.execute("DELETE FROM messages WHERE id=?", (row[0],))
    conn.commit()
    conn.close()
    return len(ids)

# --- Стосунки ---
def get_relationships():
    conn = get_db()
    rows = conn.execute("SELECT * FROM relationships WHERE met=1 ORDER BY name").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def update_relationship(name, updates: dict):
    conn = get_db()
    existing = conn.execute("SELECT id FROM relationships WHERE name=?", (name,)).fetchone()
    if existing:
        valid = ['bond','tribe','notes','mood','avatar','met']
        sets, vals = [], []
        for k,v in updates.items():
            if k in valid: sets.append(f"{k}=?"); vals.append(v)
        if sets:
            vals.append(name)
            conn.execute(f"UPDATE relationships SET {','.join(sets)} WHERE name=?", vals)
    else:
        conn.execute("INSERT INTO relationships (name,bond,tribe,notes,mood,avatar,met) VALUES (?,?,?,?,?,?,?)",
            (name, updates.get('bond',0), updates.get('tribe',''), updates.get('notes',''),
             updates.get('mood','нейтральний'), updates.get('avatar',''), updates.get('met',1)))
    conn.commit()
    conn.close()

# --- Репутація племен ---
def get_tribe_reputations():
    conn = get_db()
    rows = conn.execute("SELECT * FROM tribe_reputation ORDER BY tribe_name").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def update_tribe_reputation(tribe_name, updates: dict):
    conn = get_db()
    valid = ['reputation','status','has_house','house_level','notes']
    sets, vals = [], []
    for k,v in updates.items():
        if k in valid: sets.append(f"{k}=?"); vals.append(v)
    if sets:
        vals.append(tribe_name)
        conn.execute(f"UPDATE tribe_reputation SET {','.join(sets)} WHERE tribe_name=?", vals)
        conn.commit()
    conn.close()

# --- Інвентар ---
def get_inventory():
    conn = get_db()
    rows = conn.execute("SELECT * FROM inventory ORDER BY item_type, name").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def add_inventory_item(name, item_type='misc', quantity=1, description='', effects=''):
    conn = get_db()
    existing = conn.execute("SELECT id,quantity FROM inventory WHERE name=?", (name,)).fetchone()
    if existing:
        conn.execute("UPDATE inventory SET quantity=quantity+? WHERE id=?", (quantity, existing[0]))
    else:
        conn.execute("INSERT INTO inventory (name,item_type,quantity,description,effects) VALUES (?,?,?,?,?)",
                     (name, item_type, quantity, description, effects))
    conn.commit()
    conn.close()

def remove_inventory_item(name, quantity=1):
    conn = get_db()
    existing = conn.execute("SELECT id,quantity FROM inventory WHERE name=?", (name,)).fetchone()
    if existing:
        new_qty = existing[1] - quantity
        if new_qty <= 0:
            conn.execute("DELETE FROM inventory WHERE id=?", (existing[0],))
        else:
            conn.execute("UPDATE inventory SET quantity=? WHERE id=?", (new_qty, existing[0]))
        conn.commit()
    conn.close()

# --- Квести ---
def get_quests(status=None):
    conn = get_db()
    if status:
        rows = conn.execute("SELECT * FROM quests WHERE status=? ORDER BY id", (status,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM quests ORDER BY status, id").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def upsert_quest(title, updates: dict):
    conn = get_db()
    existing = conn.execute("SELECT id FROM quests WHERE title=?", (title,)).fetchone()
    if existing:
        valid = ['description','status','progress','giver','reward','completed_day']
        sets, vals = [], []
        for k,v in updates.items():
            if k in valid: sets.append(f"{k}=?"); vals.append(v)
        if sets:
            vals.append(existing[0])
            conn.execute(f"UPDATE quests SET {','.join(sets)} WHERE id=?", vals)
    else:
        conn.execute("INSERT INTO quests (title,description,status,progress,giver,reward,created_day) VALUES (?,?,?,?,?,?,?)",
            (title, updates.get('description',''), updates.get('status','active'),
             updates.get('progress',''), updates.get('giver',''), updates.get('reward',''),
             updates.get('created_day',1)))
    conn.commit()
    conn.close()

# --- Навички ---
def get_skills():
    conn = get_db()
    rows = conn.execute("SELECT * FROM skills ORDER BY category, name").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def update_skill(name, exp_gain=0, level_up=False):
    conn = get_db()
    skill = conn.execute("SELECT * FROM skills WHERE name=?", (name,)).fetchone()
    if skill:
        new_exp = skill['experience'] + exp_gain
        new_level = skill['level'] + (1 if level_up else 0)
        if new_exp >= 100 and new_level < skill['max_level']:
            new_level += 1; new_exp = 0
        conn.execute("UPDATE skills SET experience=?, level=? WHERE name=?", (min(new_exp,100), min(new_level,10), name))
        conn.commit()
    conn.close()

# --- Щоденник ---
def get_diary_entries():
    conn = get_db()
    rows = conn.execute("SELECT * FROM diary_entries ORDER BY id DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def add_diary_entry(day, time_of_day, content, mood=''):
    conn = get_db()
    conn.execute("INSERT INTO diary_entries (day, time_of_day, content, mood) VALUES (?,?,?,?)",
                 (day, time_of_day, content, mood))
    conn.commit()
    conn.close()

# --- Нотатки гравця ---
def get_player_notes():
    conn = get_db()
    rows = conn.execute("SELECT * FROM player_notes ORDER BY id DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def add_player_note(content):
    conn = get_db()
    conn.execute("INSERT INTO player_notes (content) VALUES (?)", (content,))
    conn.commit()
    conn.close()

def delete_player_note(note_id):
    conn = get_db()
    conn.execute("DELETE FROM player_notes WHERE id=?", (note_id,))
    conn.commit()
    conn.close()

# --- Лор / Бестіарій ---
def get_lore_entries():
    conn = get_db()
    rows = conn.execute("SELECT * FROM lore_entries ORDER BY category, title").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def add_lore_entry(category, title, content, day=1):
    conn = get_db()
    existing = conn.execute("SELECT id FROM lore_entries WHERE title=?", (title,)).fetchone()
    if not existing:
        conn.execute("INSERT INTO lore_entries (category,title,content,discovered_day) VALUES (?,?,?,?)",
                     (category, title, content, day))
        conn.commit()
    conn.close()

# --- Досягнення ---
def get_achievements():
    conn = get_db()
    rows = conn.execute("SELECT * FROM achievements ORDER BY unlocked DESC, name").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def unlock_achievement(name, day=1):
    conn = get_db()
    conn.execute("UPDATE achievements SET unlocked=1, unlocked_day=? WHERE name=? AND unlocked=0", (day, name))
    conn.commit()
    conn.close()

# --- Еволюція тіла ---
def get_body_evolutions():
    conn = get_db()
    rows = conn.execute("SELECT * FROM body_evolution ORDER BY day_acquired").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def add_body_evolution(body_part, change_type, description, source='', day=1):
    conn = get_db()
    conn.execute("INSERT INTO body_evolution (body_part,change_type,description,source,day_acquired) VALUES (?,?,?,?,?)",
                 (body_part, change_type, description, source, day))
    conn.commit()
    conn.close()

# --- Супутники ---
def get_companions():
    conn = get_db()
    rows = conn.execute("SELECT * FROM companions ORDER BY is_active DESC, name").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def update_companion(name, updates: dict):
    conn = get_db()
    existing = conn.execute("SELECT id FROM companions WHERE name=?", (name,)).fetchone()
    if existing:
        valid = ['tribe','bond','mood','abilities','is_active','avatar']
        sets, vals = [], []
        for k,v in updates.items():
            if k in valid: sets.append(f"{k}=?"); vals.append(v)
        if sets:
            vals.append(name)
            conn.execute(f"UPDATE companions SET {','.join(sets)} WHERE name=?", vals)
    else:
        conn.execute("INSERT INTO companions (name,tribe,bond,mood,abilities,is_active,avatar) VALUES (?,?,?,?,?,?,?)",
            (name, updates.get('tribe',''), updates.get('bond',0), updates.get('mood','нейтральний'),
             updates.get('abilities',''), updates.get('is_active',0), updates.get('avatar','')))
    conn.commit()
    conn.close()

# --- Чутки ---
def get_rumors():
    conn = get_db()
    rows = conn.execute("SELECT * FROM rumors ORDER BY spread_day DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def add_rumor(content, source_tribe='', target='', spread_day=0, expires_day=0, is_true=1):
    conn = get_db()
    conn.execute("INSERT INTO rumors (content,source_tribe,target,spread_day,expires_day,is_true) VALUES (?,?,?,?,?,?)",
                 (content, source_tribe, target, spread_day, expires_day, is_true))
    conn.commit()
    conn.close()

# --- Події за розкладом ---
def get_scheduled_events(day=None):
    conn = get_db()
    if day:
        rows = conn.execute("SELECT * FROM scheduled_events WHERE trigger_day<=? AND completed=0 ORDER BY trigger_day", (day,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM scheduled_events ORDER BY trigger_day").fetchall()
    conn.close()
    return [dict(r) for r in rows]

# --- Локації ---
def get_locations():
    conn = get_db()
    rows = conn.execute("SELECT * FROM locations ORDER BY region, name").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def discover_location(name):
    conn = get_db()
    conn.execute("UPDATE locations SET discovered=1 WHERE name=?", (name,))
    conn.commit()
    conn.close()

def get_discovered_locations():
    conn = get_db()
    rows = conn.execute("SELECT * FROM locations WHERE discovered=1 ORDER BY region, name").fetchall()
    conn.close()
    return [dict(r) for r in rows]

# --- Торгівля ---
def get_trade_offers(tribe=None):
    conn = get_db()
    if tribe:
        rows = conn.execute("SELECT * FROM trade_offers WHERE tribe=? AND available=1", (tribe,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM trade_offers WHERE available=1").fetchall()
    conn.close()
    return [dict(r) for r in rows]

# --- Сни ---
def get_dreams():
    conn = get_db()
    rows = conn.execute("SELECT * FROM dreams ORDER BY day DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def add_dream(day, dream_type, content, effects=''):
    conn = get_db()
    conn.execute("INSERT INTO dreams (day,dream_type,content,effects) VALUES (?,?,?,?)",
                 (day, dream_type, content, effects))
    conn.commit()
    conn.close()

# --- Підсумки пам'яті ---
def get_summaries():
    conn = get_db()
    rows = conn.execute("SELECT * FROM story_summaries ORDER BY id ASC").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def add_summary(text, msgs_covered):
    conn = get_db()
    conn.execute("INSERT INTO story_summaries (summary, messages_covered) VALUES (?,?)", (text, msgs_covered))
    conn.commit()
    conn.close()

# --- Токени ---
def log_token_usage(model, input_t, output_t, cost, purpose=''):
    conn = get_db()
    conn.execute("INSERT INTO token_usage (model,input_tokens,output_tokens,cost_usd,purpose) VALUES (?,?,?,?,?)",
                 (model, input_t, output_t, cost, purpose))
    conn.commit()
    conn.close()

def get_token_stats():
    conn = get_db()
    rows = conn.execute("""
        SELECT model, SUM(input_tokens) as total_in, SUM(output_tokens) as total_out,
               SUM(cost_usd) as total_cost, COUNT(*) as calls
        FROM token_usage GROUP BY model
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]

# --- Збереження ---
def save_game(slot_name="auto"):
    conn = get_db()
    tables = ['game_state','messages','relationships','tribe_reputation','inventory',
              'quests','skills','diary_entries','lore_entries','achievements',
              'body_evolution','companions','rumors','scheduled_events','story_summaries',
              'locations','trade_offers','dreams','player_notes']
    dump = {}
    for t in tables:
        rows = conn.execute(f"SELECT * FROM {t}").fetchall()
        dump[t] = [dict(r) for r in rows]
    conn.execute("INSERT OR REPLACE INTO save_slots (slot_name, full_dump, created_at) VALUES (?,?,datetime('now'))",
                 (slot_name, json.dumps(dump, ensure_ascii=False)))
    conn.commit()
    conn.close()
    return f"✅ Збережено: {slot_name}"

def load_game(slot_name="auto"):
    conn = get_db()
    row = conn.execute("SELECT full_dump FROM save_slots WHERE slot_name=?", (slot_name,)).fetchone()
    if not row:
        conn.close()
        return f"❌ Слот '{slot_name}' не знайдено"
    dump = json.loads(row[0])
    skip_tables = ['save_slots','token_usage']
    for table, rows in dump.items():
        if table in skip_tables:
            continue
        conn.execute(f"DELETE FROM {table}")
        if rows:
            cols = list(rows[0].keys())
            placeholders = ','.join(['?' for _ in cols])
            col_names = ','.join(cols)
            for r in rows:
                conn.execute(f"INSERT INTO {table} ({col_names}) VALUES ({placeholders})",
                             [r.get(c) for c in cols])
    conn.commit()
    conn.close()
    return f"✅ Завантажено: {slot_name}"

def get_save_slots():
    conn = get_db()
    rows = conn.execute("SELECT slot_name, created_at FROM save_slots ORDER BY created_at DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]

# --- Бекапи ---
def create_backup():
    if DB_PATH.exists():
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_path = BACKUP_DIR / f"game_backup_{ts}.db"
        shutil.copy2(str(DB_PATH), str(backup_path))
        # Зберігати максимум 20 бекапів
        backups = sorted(BACKUP_DIR.glob('game_backup_*.db'))
        while len(backups) > 20:
            backups[0].unlink()
            backups.pop(0)
        return str(backup_path)
    return None

def list_backups():
    return sorted([f.name for f in BACKUP_DIR.glob('game_backup_*.db')], reverse=True)

def restore_backup(filename):
    path = BACKUP_DIR / filename
    if path.exists():
        shutil.copy2(str(path), str(DB_PATH))
        return True
    return False

# --- Повний скид ---
def full_reset():
    conn = get_db()
    tables = ['messages','relationships','inventory','quests','diary_entries',
              'player_notes','lore_entries','body_evolution','companions','rumors',
              'story_summaries','dreams','trade_offers']
    for t in tables:
        conn.execute(f"DELETE FROM {t}")
    conn.execute("""UPDATE game_state SET
        strength=7, agility=8, endurance=7, charisma=6, willpower=8,
        desire=0, shame=70, confidence=30,
        health=100, max_health=100, hunger=100, thirst=100, energy=100,
        location='Пляж після аварії', time_of_day='ранок', current_day=1,
        is_pregnant=0, pregnancy_father='', pregnancy_day=0,
        amulet_energy=100, home_location='', home_level=0,
        companion_name='', companion_tribe='',
        is_dead=0, death_reason='', game_started=0
        WHERE id='main'""")
    conn.execute("UPDATE skills SET level=1, experience=0")
    conn.execute("UPDATE achievements SET unlocked=0, unlocked_day=0")
    conn.execute("UPDATE tribe_reputation SET reputation=0, status='невідомі', has_house=0, house_level=0, notes=''")
    conn.execute("UPDATE tribe_reputation SET status='нейтральні' WHERE tribe_name='Кай-Тору'")
    conn.execute("UPDATE locations SET discovered=0")
    conn.execute("UPDATE locations SET discovered=1 WHERE name='Пляж після аварії'")
    conn.commit()
    conn.close()
