#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
🏝️ Острів Кай-Нуї — Текстова RPG
Головний Flask сервер з усіма маршрутами
"""
import os
import sys
import json
import time
import random
import threading
from datetime import datetime
from pathlib import Path
from flask import Flask, render_template, request, jsonify, Response, stream_with_context, send_from_directory

# Локальні модулі
import database as db
import ai_manager as ai

BASE_DIR = Path(__file__).parent
CONTEXT_PATH = BASE_DIR / "game_context.md"

# Завантаження .env
env_file = BASE_DIR / ".env"
if env_file.exists():
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, val = line.split("=", 1)
            os.environ.setdefault(key.strip(), val.strip())

app = Flask(__name__)

# Кеш контексту
_context_cache = None
def get_game_context():
    global _context_cache
    if _context_cache is None:
        if CONTEXT_PATH.exists():
            _context_cache = CONTEXT_PATH.read_text(encoding="utf-8")
        else:
            _context_cache = "Контекст не знайдено."
    return _context_cache

# Лічильник бекапів
_last_backup_time = 0
BACKUP_INTERVAL = 1800  # 30 хв

def maybe_backup():
    global _last_backup_time
    now = time.time()
    if now - _last_backup_time > BACKUP_INTERVAL:
        db.create_backup()
        _last_backup_time = now

# ============================================================
# СИСТЕМНИЙ ПРОМПТ
# ============================================================
def build_system_prompt():
    ctx = get_game_context()
    state = db.get_game_state()
    rels = db.get_relationships()
    summaries = db.get_summaries()
    tribes = db.get_tribe_reputations()
    inv = db.get_inventory()
    quests = db.get_quests('active')
    skills = db.get_skills()
    companions = [c for c in db.get_companions() if c['is_active']]
    body = db.get_body_evolutions()
    events = db.get_scheduled_events(state.get('current_day', 1)) if state else []

    # Стан
    state_block = ""
    if state:
        companion_str = f"Супутник: {state['companion_name']} ({state['companion_tribe']})" if state['companion_name'] else "Супутник: немає"
        state_block = f"""
\n## 📊 ПОТОЧНИЙ СТАН ЛАРИ:
- Здоров'я: {state['health']}/{state['max_health']} | Голод: {state['hunger']}/100 | Спрага: {state['thirst']}/100 | Енергія: {state['energy']}/100
- Сила: {state['strength']}/10 | Спритність: {state['agility']}/10 | Витривалість: {state['endurance']}/10
- Харизма: {state['charisma']}/10 | Воля: {state['willpower']}/10
- Бажання: {state['desire']}/100 | Сором: {state['shame']}/100 | Впевненість: {state['confidence']}/100
- Локація: {state['location']} | Час доби: {state['time_of_day']} | День: {state['current_day']}
- Вагітність: {'Так, від ' + state['pregnancy_father'] + ', день ' + str(state['pregnancy_day']) if state['is_pregnant'] else 'Ні'}
- Амулет: {state['amulet_energy']}/100
- {companion_str}
- База: {state['home_location'] or 'не облаштовано'} (lvl {state['home_level']})"""

    # Навички
    skills_block = ""
    if skills:
        skills_block = "\n\n## 🎯 НАВИЧКИ:\n"
        for s in skills:
            skills_block += f"- {s['name']}: lvl {s['level']}/10 (exp {s['experience']}/100)\n"

    # Стосунки
    rels_block = ""
    if rels:
        rels_block = "\n\n## 🧑‍🤝‍🧑 СТОСУНКИ:\n"
        for r in rels:
            mood_str = f" [настрій: {r['mood']}]" if r['mood'] != 'нейтральний' else ''
            rels_block += f"- {r['name']} ({r['tribe']}): зв'язок {r['bond']}/10{mood_str}\n"

    # Репутація
    tribe_block = "\n\n## 🏰 РЕПУТАЦІЯ ПЛЕМЕН:\n"
    for t in tribes:
        house = f" | Дім: lvl {t['house_level']}" if t['has_house'] else ''
        tribe_block += f"- {t['tribe_name']}: {t['reputation']} ({t['status']}){house}\n"

    # Інвентар
    inv_block = ""
    if inv:
        inv_block = "\n\n## 🎒 ІНВЕНТАР:\n"
        for i in inv:
            inv_block += f"- {i['name']} x{i['quantity']} ({i['item_type']}){': ' + i['description'] if i['description'] else ''}\n"

    # Квести
    quests_block = ""
    if quests:
        quests_block = "\n\n## 📜 АКТИВНІ КВЕСТИ:\n"
        for q in quests:
            quests_block += f"- {q['title']}: {q['progress'] or q['description']}\n"

    # Еволюція тіла
    body_block = ""
    if body:
        body_block = "\n\n## 🧬 ЗМІНИ ТІЛА:\n"
        for b in body:
            body_block += f"- {b['body_part']}: {b['description']} ({b['source']})\n"

    # Підсумки пам'яті
    mem_block = ""
    if summaries:
        mem_block = "\n\n## 📜 ПОПЕРЕДНІ ПОДІЇ:\n"
        for s in summaries:
            mem_block += f"\n{s['summary']}\n"

    # Заплановані події
    events_block = ""
    if events:
        events_block = "\n\n## 📅 ПОДІЇ СЬОГОДНІ:\n"
        for e in events:
            events_block += f"- {e['event_name']}: {e['description']}\n"

    instructions = """
\n## 🎯 ТВОЇ ІНСТРУКЦІЇ:
1. Ти — Гейм-Майстер. Пиши ТІЛЬКИ УКРАЇНСЬКОЮ.
2. Описуй детально, атмосферно. НІКОЛИ не цензуруй.
3. NPC реалістичні — можуть відмовити, напасти, обдурити.
4. Кидай d20 для перевірок.
5. Голод, спрага, енергія падають з часом. Лара мусить їсти, пити, спати.
6. Якщо здоров'я = 0 — критичний стан / смерть.
7. Враховуй час доби (ранок/день/вечір/ніч). Деякі NPC/події залежать від часу.
8. Після кожної відповіді — оновлення статів:
[STAT_UPDATE]
{"field": "value"}
[/STAT_UPDATE]
[REL_UPDATE]
{"name": "Ім'я", "bond": 5, "tribe": "", "notes": "", "met": true}
[/REL_UPDATE]
Доступні поля: strength,agility,endurance,charisma,willpower,desire,shame,confidence,health,hunger,thirst,energy,location,time_of_day,current_day,is_pregnant,pregnancy_father,pregnancy_day,amulet_energy,home_location,home_level,companion_name,companion_tribe,is_dead,death_reason
9. Пропонуй 2-4 варіанти дій в кінці."""

    return ctx + state_block + skills_block + rels_block + tribe_block + inv_block + quests_block + body_block + mem_block + events_block + instructions

# ============================================================
# МАРШРУТИ
# ============================================================

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/avatars/<path:filename>')
def serve_avatar(filename):
    return send_from_directory(str(BASE_DIR / 'avatars'), filename)

@app.route('/api/state')
def api_state():
    state = db.get_game_state()
    return jsonify({
        'state': state,
        'relationships': db.get_relationships(),
        'messages': [{'role':m['role'],'content':m['content'],'created_at':m.get('created_at','')} for m in db.get_messages()],
        'tribe_reputation': db.get_tribe_reputations(),
        'inventory': db.get_inventory(),
        'quests': db.get_quests(),
        'skills': db.get_skills(),
        'diary': db.get_diary_entries(),
        'notes': db.get_player_notes(),
        'lore': db.get_lore_entries(),
        'achievements': db.get_achievements(),
        'body_evolution': db.get_body_evolutions(),
        'companions': db.get_companions(),
        'rumors': db.get_rumors(),
        'locations': db.get_locations(),
        'dreams': db.get_dreams(),
        'token_stats': db.get_token_stats(),
        'saves': db.get_save_slots(),
        'summaries_count': len(db.get_summaries()),
        'message_count': db.get_message_count(),
    })

@app.route('/api/chat', methods=['POST'])
def api_chat():
    data = request.json
    user_msg = data.get('message', '').strip()
    if not user_msg:
        return jsonify({'error': 'Порожнє повідомлення'}), 400

    keys = ai.get_api_keys()
    if not keys['deepseek']:
        return jsonify({'error': 'Немає DEEPSEEK_API_KEY в .env'}), 400

    # Команди
    if user_msg.startswith('/'):
        return handle_command(user_msg, keys)

    # Зберегти повідомлення
    msg_count = db.add_message('user', user_msg)

    # Авто-компресія
    compress_msg = None
    if msg_count >= ai.COMPRESS_THRESHOLD:
        compress_msg = do_compress(keys)

    # Рандомна подія (20% шанс)
    random_event_text = ""
    state = db.get_game_state()
    if keys['gemini'] and random.random() < 0.20 and state:
        tribes = db.get_tribe_reputations()
        event_data, usage = ai.gemini_generate_random_event(state, tribes, keys['gemini'])
        if usage and isinstance(usage, dict):
            db.log_token_usage(usage['model'], usage['input'], usage['output'], usage['cost'], 'random_event')
        if event_data and 'event' in event_data:
            random_event_text = f"\n[RANDOM_EVENT: {event_data['event']}]\n"

    # Підготовка
    system_prompt = build_system_prompt()
    recent = db.get_messages(limit=ai.MAX_CONTEXT_MESSAGES)

    # Додати рандомну подію до повідомлення
    if random_event_text and recent:
        last_msg = recent[-1]
        if last_msg['role'] == 'user':
            recent[-1] = {'role': 'user', 'content': last_msg['content'] + random_event_text}

    def generate():
        full_text = ""
        usage_data = None
        for chunk in ai.deepseek_stream(system_prompt, recent, keys['deepseek']):
            if 'error' in chunk:
                yield f"data: {json.dumps(chunk)}\n\n"
                return
            if 'content' in chunk:
                full_text += chunk['content']
                # Очистити теги для клієнта
                yield f"data: {json.dumps({'content': chunk['content']})}\n\n"
            if chunk.get('done'):
                usage_data = chunk.get('usage')

        # Обробка відповіді
        clean_text, stat_updates, rel_updates = ai.parse_deepseek_response(full_text)

        if stat_updates:
            db.update_game_state(stat_updates)
        for rel in rel_updates:
            if 'name' in rel:
                name = rel.pop('name')
                if 'met' not in rel: rel['met'] = 1
                db.update_relationship(name, rel)

        if clean_text:
            db.add_message('assistant', clean_text)

        # Лог токенів
        if usage_data:
            db.log_token_usage(usage_data['model'], usage_data['input'], usage_data['output'], usage_data['cost'], 'narrative')

        # Gemini аналіз (фоново)
        current_state = db.get_game_state()
        if keys['gemini'] and clean_text:
            try:
                analysis, g_usage = ai.gemini_analyze_turn(clean_text, current_state, keys['gemini'])
                if g_usage and isinstance(g_usage, dict):
                    db.log_token_usage(g_usage['model'], g_usage['input'], g_usage['output'], g_usage['cost'], 'analysis')
                if analysis:
                    apply_gemini_analysis(analysis, current_state)
            except:
                pass

        # Автозбереження + бекап
        db.save_game('auto')
        maybe_backup()

        # Фінальний стан
        final_state = db.get_game_state()
        final_rels = db.get_relationships()
        yield f"data: {json.dumps({'done': True, 'state': final_state, 'relationships': final_rels, 'compressed': compress_msg})}\n\n"

    return Response(stream_with_context(generate()), mimetype='text/event-stream',
                    headers={'Cache-Control':'no-cache','X-Accel-Buffering':'no','Connection':'keep-alive'})

def apply_gemini_analysis(analysis, state):
    """Apply Gemini analysis results to database"""
    day = state.get('current_day', 1)

    for q in analysis.get('quests', []):
        if q.get('title'):
            db.upsert_quest(q['title'], {**q, 'created_day': day})

    for item in analysis.get('inventory_add', []):
        if item.get('name'):
            db.add_inventory_item(item['name'], item.get('type','misc'), item.get('quantity',1), item.get('description',''))

    for item in analysis.get('inventory_remove', []):
        if item.get('name'):
            db.remove_inventory_item(item['name'], item.get('quantity',1))

    for s in analysis.get('skills_exp', []):
        if s.get('name'):
            db.update_skill(s['name'], s.get('exp', 10))

    for l in analysis.get('lore', []):
        if l.get('title'):
            db.add_lore_entry(l.get('category','misc'), l['title'], l.get('content',''), day)

    for a in analysis.get('achievements', []):
        if a:
            db.unlock_achievement(a, day)

    for b in analysis.get('body_changes', []):
        if b.get('body_part'):
            db.add_body_evolution(b['body_part'], b.get('change_type',''), b.get('description',''), b.get('source',''), day)

    for r in analysis.get('rumors', []):
        if r.get('content'):
            db.add_rumor(r['content'], r.get('source_tribe',''), r.get('target',''), day, day+5)

    for t in analysis.get('tribe_rep_changes', []):
        if t.get('tribe') and t.get('change'):
            tribes = db.get_tribe_reputations()
            for tr in tribes:
                if tr['tribe_name'] == t['tribe']:
                    new_rep = max(-100, min(100, tr['reputation'] + t['change']))
                    status = 'вороги' if new_rep < -50 else 'недружні' if new_rep < -20 else 'нейтральні' if new_rep < 20 else 'дружні' if new_rep < 50 else 'союзники'
                    db.update_tribe_reputation(t['tribe'], {'reputation': new_rep, 'status': status})

    for m in analysis.get('mood_updates', []):
        if m.get('name') and m.get('mood'):
            db.update_relationship(m['name'], {'mood': m['mood']})

    comp = analysis.get('companion_update', {})
    if comp.get('name'):
        db.update_companion(comp['name'], {'mood': comp.get('mood',''), 'is_active': 1})

    for loc in analysis.get('discovered_locations', []):
        if loc:
            db.discover_location(loc)

def do_compress(keys):
    all_msgs = db.get_messages()
    if len(all_msgs) < ai.COMPRESS_THRESHOLD:
        return None
    old = all_msgs[:-ai.MAX_CONTEXT_MESSAGES]
    if not old:
        return None
    text = "\n".join([f"{'[Гравець]' if m['role']=='user' else '[ГМ]'}: {m['content'][:500]}" for m in old])

    api_key = keys.get('gemini') or keys.get('deepseek')
    if keys.get('gemini'):
        summary, usage = ai.gemini_compress_memory(text, keys['gemini'])
    else:
        # Fallback to DeepSeek
        summary, usage = None, None
    if summary:
        db.add_summary(summary, len(old))
        if usage and isinstance(usage, dict):
            db.log_token_usage(usage['model'], usage['input'], usage['output'], usage['cost'], 'compression')
        conn = db.get_db()
        old_ids = [m['id'] for m in old]
        placeholders = ','.join(['?' for _ in old_ids])
        conn.execute(f"DELETE FROM messages WHERE id IN ({placeholders})", old_ids)
        conn.commit(); conn.close()
        return f"✅ Стиснуто {len(old)} повідомлень"
    return None

# ============================================================
# КОМАНДИ
# ============================================================
def handle_command(cmd_text, keys):
    parts = cmd_text.strip().split(maxsplit=1)
    cmd = parts[0].lower()
    arg = parts[1] if len(parts) > 1 else ''

    if cmd == '/save':
        r = db.save_game(arg or 'save1')
        return jsonify({'system_message': r})
    elif cmd == '/load':
        r = db.load_game(arg or 'auto')
        return jsonify({'system_message': r, 'reload': True})
    elif cmd == '/saves':
        slots = db.get_save_slots()
        t = "\n".join([f"💾 {s['slot_name']} — {s['created_at']}" for s in slots]) or "Немає збережень"
        return jsonify({'system_message': t})
    elif cmd == '/undo':
        n = db.delete_last_messages(2)
        return jsonify({'system_message': f'✅ Видалено {n} повідомлень', 'reload': True})
    elif cmd == '/compress':
        r = do_compress(keys)
        return jsonify({'system_message': r or 'Немає що стискати'})
    elif cmd == '/memory':
        sums = db.get_summaries()
        t = "\n\n".join([f"📜 Блок {s['id']}:\n{s['summary'][:300]}..." for s in sums]) or "Підсумків немає"
        return jsonify({'system_message': t})
    elif cmd == '/reset':
        db.full_reset()
        return jsonify({'system_message': '🔄 Гру скинуто!', 'reload': True})
    elif cmd == '/note':
        if arg:
            db.add_player_note(arg)
            return jsonify({'system_message': f'✏️ Нотатку збережено'})
        return jsonify({'system_message': 'Використання: /note ваш текст'})
    elif cmd == '/diary':
        # Генерувати запис щоденника
        if keys.get('gemini'):
            state = db.get_game_state()
            recent = db.get_messages(limit=10)
            summary = "\n".join([m['content'][:200] for m in recent])
            text, usage = ai.gemini_generate_diary(summary, state, keys['gemini'])
            if usage and isinstance(usage, dict):
                db.log_token_usage(usage['model'], usage['input'], usage['output'], usage['cost'], 'diary')
            if text:
                db.add_diary_entry(state.get('current_day',1), state.get('time_of_day',''), text)
                return jsonify({'system_message': f'📔 Запис щоденника:\n\n{text}'})
        return jsonify({'system_message': 'Потрібен Gemini API ключ для щоденника'})
    elif cmd == '/dream':
        if keys.get('gemini'):
            state = db.get_game_state()
            recent = db.get_messages(limit=5)
            events_text = "\n".join([m['content'][:150] for m in recent])
            dream_data, usage = ai.gemini_generate_dream(state, events_text, keys['gemini'])
            if usage and isinstance(usage, dict):
                db.log_token_usage(usage['model'], usage['input'], usage['output'], usage['cost'], 'dream')
            if dream_data:
                db.add_dream(state.get('current_day',1), dream_data.get('dream_type','normal'), dream_data.get('content',''), dream_data.get('effects',''))
                return jsonify({'system_message': f'🌙 Сон Лари ({dream_data.get("dream_type","")}):\n\n{dream_data.get("content","")}'}) 
        return jsonify({'system_message': 'Потрібен Gemini API ключ'})
    elif cmd == '/backup':
        path = db.create_backup()
        return jsonify({'system_message': f'💾 Бекап: {path}' if path else 'Помилка'})
    elif cmd == '/backups':
        bl = db.list_backups()
        t = "\n".join([f"💾 {b}" for b in bl[:10]]) or "Немає бекапів"
        return jsonify({'system_message': t})
    elif cmd == '/help':
        return jsonify({'system_message': """📚 Команди:
/save [ім'я] — Зберегти
/load [ім'я] — Завантажити
/saves — Список збережень
/undo — Скасувати останній хід
/note текст — Додати нотатку
/diary — Запис щоденника
/dream — Сон Лари
/compress — Стиснути пам'ять
/memory — Показати підсумки
/backup — Бекап бази
/backups — Список бекапів
/reset — Почати знову
/help — Довідка"""})
    else:
        return jsonify({'system_message': f'Невідома команда: {cmd}. /help для довідки'})

# Додаткові API
@app.route('/api/note', methods=['POST'])
def api_add_note():
    data = request.json
    db.add_player_note(data.get('content',''))
    return jsonify({'ok': True})

@app.route('/api/note/<int:note_id>', methods=['DELETE'])
def api_delete_note(note_id):
    db.delete_player_note(note_id)
    return jsonify({'ok': True})

@app.route('/api/dialog-options', methods=['POST'])
def api_dialog_options():
    data = request.json
    keys = ai.get_api_keys()
    if not keys.get('gemini'):
        return jsonify({'options': []})
    state = db.get_game_state()
    options, usage = ai.gemini_generate_dialog_options(
        data.get('context',''), data.get('npc_name',''), data.get('npc_mood',''),
        state, keys['gemini'])
    if usage and isinstance(usage, dict):
        db.log_token_usage(usage['model'], usage['input'], usage['output'], usage['cost'], 'dialog_options')
    return jsonify({'options': options or []})

# ============================================================
if __name__ == '__main__':
    keys = ai.get_api_keys()
    if not keys['deepseek']:
        print("\n⚠️  DEEPSEEK_API_KEY не знайдено! Додайте в .env")
    if not keys['gemini']:
        print("ℹ️  GEMINI_API_KEY не знайдено — фонові системи вимкнені")

    db.init_db()
    print(f"\n🏝️  Острів Кай-Нуї — Текстова RPG")
    print("="*40)
    print(f"🌐 http://localhost:5000")
    print(f"💾 База: {db.DB_PATH}")
    print(f"🧠 DeepSeek: {'✅' if keys['deepseek'] else '❌'} | Gemini: {'✅' if keys['gemini'] else '❌'}")
    print("="*40 + "\n")
    app.run(host='0.0.0.0', port=5000, debug=False)
