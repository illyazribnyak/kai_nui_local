export interface GameState {
  id: string
  strength: number
  agility: number
  endurance: number
  charisma: number
  willpower: number
  desire: number
  shame: number
  confidence: number
  location: string
  isPregnant: boolean
  pregnancyWeek: number
  pregnancyFather: string | null
  amuletEnergy: number
  dayNumber: number
  isDarkLara: boolean
  gameStarted: boolean
}

export interface MessageData {
  id: string
  role: string
  content: string
  createdAt: string
}

export interface RelationshipData {
  id: string
  name: string
  bond: number
  tribe: string
  notes: string
  met: boolean
}

export interface StatUpdate {
  strength?: number
  agility?: number
  endurance?: number
  charisma?: number
  willpower?: number
  desire?: number
  shame?: number
  confidence?: number
  location?: string
  isPregnant?: boolean
  pregnancyWeek?: number
  pregnancyFather?: string | null
  amuletEnergy?: number
  dayNumber?: number
  isDarkLara?: boolean
}

export interface RelationshipUpdate {
  name: string
  bond?: number
  tribe?: string
  notes?: string
  met?: boolean
}

export interface InventoryItemData {
  id: string
  name: string
  description: string
  quantity: number
  category: string
}

export interface QuestData {
  id: string
  title: string
  description: string
  status: string
  givenBy: string
}

export interface DiaryEntryData {
  id: string
  title: string
  content: string
  dayNumber: number
  createdAt: string
}

export interface InventoryUpdate {
  action: 'add' | 'remove' | 'update'
  name: string
  description?: string
  quantity?: number
  category?: string
}

export interface QuestUpdate {
  action: 'add' | 'complete' | 'fail' | 'update'
  title: string
  description?: string
  givenBy?: string
}

export interface DiaryUpdate {
  title?: string
  content: string
}

export interface SkillData {
  id: string
  name: string
  level: number
  xp: number
  maxXp: number
  category: string
  description: string
}

export interface SkillUpdate {
  name: string
  xp: number
}
