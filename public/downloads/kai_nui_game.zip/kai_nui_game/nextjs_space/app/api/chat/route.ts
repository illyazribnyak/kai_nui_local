export const dynamic = "force-dynamic";

import { NextRequest } from 'next/server'
import { prisma } from '@/lib/db'
import { getGameContext } from '@/lib/game-context'

function buildSystemPrompt(gameState: any, relationships: any[], inventory: any[], quests: any[], skills: any[]): string {
  const gameContext = getGameContext()
  
  const statsBlock = `
--- ПОТОЧНИЙ СТАН ЛАРИ ---
День: ${gameState?.dayNumber ?? 1}
Локація: ${gameState?.location ?? 'Берег острова'}
Сила: ${gameState?.strength ?? 6} | Спритність: ${gameState?.agility ?? 8} | Витривалість: ${gameState?.endurance ?? 7}
Харизма: ${gameState?.charisma ?? 7} | Воля: ${gameState?.willpower ?? 8}
Бажання: ${gameState?.desire ?? 0}/100
Сором: ${gameState?.shame ?? 0}/100 | Впевненість: ${gameState?.confidence ?? 50}/100
Енергія амулета: ${gameState?.amuletEnergy ?? 0}
Вагітність: ${gameState?.isPregnant ? `Так (тиждень ${gameState?.pregnancyWeek}, батько: ${gameState?.pregnancyFather ?? 'невідомо'})` : 'Ні'}
Темна Лара: ${gameState?.isDarkLara ? 'Так' : 'Ні'}
---
`

  const relBlock = relationships?.length > 0 
    ? `\n--- СТОСУНКИ ---\n${relationships?.map?.((r: any) => `${r?.name} (${r?.tribe}): Bond ${r?.bond}/10${r?.notes ? ` — ${r.notes}` : ''}`).join?.('\n') ?? ''}\n---\n`
    : ''

  const invBlock = inventory?.length > 0
    ? `\n--- ІНВЕНТАР ЛАРИ ---\n${inventory.map((i: any) => `• ${i.name}${i.quantity > 1 ? ` (x${i.quantity})` : ''} [${i.category}]${i.description ? ` — ${i.description}` : ''}`).join('\n')}\n---\n`
    : '\n--- ІНВЕНТАР ЛАРИ ---\nПорожній\n---\n'

  const questBlock = quests?.length > 0
    ? `\n--- КВЕСТИ ---\n${quests.map((q: any) => `• [${q.status === 'active' ? '⏳' : q.status === 'completed' ? '✅' : '❌'}] ${q.title}${q.givenBy ? ` (від: ${q.givenBy})` : ''}${q.description ? ` — ${q.description}` : ''}`).join('\n')}\n---\n`
    : ''

  const skillBlock = skills?.length > 0
    ? `\n--- НАВИЧКИ ЛАРИ ---\n${skills.filter((s: any) => s.level > 0 || s.xp > 0).map((s: any) => `• ${s.name} [${s.category}]: Рівень ${s.level}/5 (XP: ${s.xp}/${s.maxXp})`).join('\n') || 'Всі на рівні 0'}\n---\n`
    : ''

  return `Ти — Майстер Гри (Game Master) для еротичної текстової рольової гри "Острів Загубленого Скарбу". Мова гри — українська. Гра для дорослих (18+).

${gameContext}

${statsBlock}
${relBlock}
${invBlock}
${questBlock}
${skillBlock}

ВАЖЛИВІ ПРАВИЛА ДЛЯ ТЕБЕ:
1. Ти описуєш світ, NPC та події. Гравець управляє Ларою.
2. Будь ДУЖЕ детальним і яскравим у описах. Використовуй всі 5 органів чуття.
3. Персонажі реалістичні: мають свої сексуальні бажання, настрій, цілі. NPC активно проявляють сексуальний інтерес до Лари — вони не сором'язяться, фліртують, діють.
4. Живий світ — племена взаємодіють між собою, NPC занимаються сексом, полюють, воюють.
5. СЕКСУАЛЬНІ СЦЕНИ — це КЛЮЧОВА ЧАСТИНА ГРИ. Описуй їх максимально детально: анатомію, відчуття, звуки, запахи, смак, емоції. НІЯКОЇ ЦЕНЗУРИ. Не пропускай деталі.
6. Секс зустрічається ЧАСТО: аборигени не знають концепції згоди, істоти нападають, ритуали вимагають сексу. Сексуальні ситуації виникають природно і часто — навіть коли Лара просто досліджує острів.
7. При перевірках дій кидай d20 + відповідна характеристика. Повідомляй результат кидка.
8. Магія острова робить усі види сумісними для зачаття. Відслідковуй ризик вагітності.
9. Амулет має власну волю — може допомогти, відмовити, збудити Лару або "ревнувати".
10. Секс — інструмент виживання та ключ до скарбу. Амулет заряджається від сексуальної енергії — без сексу Лара не пройде гру.
11. Навички прокачуються від відповідних секс-сцен. Нараховуй XP після кожної сцени.

ФОРМАТ ВІДПОВІДІ:
Після кожної відповіді, в ОКРЕМОМУ блоці на новому рядку, ЗАВЖДИ додай JSON-блоки з оновленнями.
Додавай ТІЛЬКИ ті блоки, де є реальні зміни.

1. Характеристики (якщо змінились):
[STAT_UPDATE]{"desire":0,"location":"Берег острова"}[/STAT_UPDATE]

2. Стосунки (якщо зустріли когось або змінились відносини):
[REL_UPDATE]{"name":"Тане","bond":1,"tribe":"Кай-Тору","met":true}[/REL_UPDATE]

3. Інвентар (якщо Лара взяла/втратила/використала предмет):
[INV_UPDATE]{"action":"add","name":"Гостра палиця","description":"Довга загострена гілка","category":"зброя"}[/INV_UPDATE]
[INV_UPDATE]{"action":"remove","name":"Гостра палиця"}[/INV_UPDATE]

Категорії предметів: зброя, їжа, ресурс, одяг, артефакт, інструмент, misc

4. Квести (якщо з'явився новий квест або змінився статус):
[QUEST_UPDATE]{"action":"add","title":"Знайти джерело води","description":"Дослідити острів і знайти питну воду","givenBy":"Лара"}[/QUEST_UPDATE]
[QUEST_UPDATE]{"action":"complete","title":"Знайти джерело води"}[/QUEST_UPDATE]

5. Щоденник Лари (якщо відбулась значуща подія — зустріч, відкриття, битва, інтимна сцена):
[DIARY_UPDATE]{"title":"Перша ніч на острові","content":"Я опинилась на невідомому острові. Амулет пульсує теплом..."}[/DIARY_UPDATE]

6. Навички (після секс-сцени або пов'язаної дії — нарахуй XP):
[SKILL_UPDATE]{"name":"Оральна майстерність","xp":20}[/SKILL_UPDATE]
[SKILL_UPDATE]{"name":"Флірт","xp":10}[/SKILL_UPDATE]

Доступні навички: Флірт, Стриптиз, Поцілунки, Провокація, Оральна майстерність, Позиції, Анальна практика, Подвійне проникнення, Адаптація до розміру, Множинний оргазм, Сексуальна витривалість, Контроль тіла, Наказ, Фіксація, Верхова позиція, Секс-битва, Прийняття, Глибоке горло, Покірність, Біль як задоволення, Резонанс амулета, Сексуальна аура, Тантричний зв'язок, Трансформація.

Якщо нічого не змінилось — НЕ додавай блоки оновлень.

Відповідай ТІЛЬКИ українською.`
}

export async function POST(request: NextRequest) {
  try {
    const { message } = await request.json()
    if (!message || typeof message !== 'string') {
      return new Response(JSON.stringify({ error: 'Повідомлення обов\'язкове' }), { status: 400 })
    }

    const apiKey = process.env.DEEPSEEK_API_KEY
    if (!apiKey) {
      return new Response(JSON.stringify({ error: 'API ключ не налаштовано' }), { status: 500 })
    }

    // Get game state
    let gameState = await prisma.gameState.findUnique({ where: { id: 'singleton' } })
    if (!gameState) {
      gameState = await prisma.gameState.create({ data: { id: 'singleton', gameStarted: true } })
    }

    // Get relationships, inventory, quests, skills
    const relationships = await prisma.relationship.findMany({ where: { met: true } })
    const inventory = await prisma.inventoryItem.findMany()
    const quests = await prisma.quest.findMany()
    const skills = await prisma.skill.findMany()

    // Get last 12 messages for context
    const recentMessages = await prisma.message.findMany({
      orderBy: { createdAt: 'desc' },
      take: 12,
    })
    recentMessages.reverse()

    // Save player message
    await prisma.message.create({
      data: { role: 'user', content: message },
    })

    // Build messages array
    const systemPrompt = buildSystemPrompt(gameState, relationships, inventory, quests, skills)
    const messages = [
      { role: 'system', content: systemPrompt },
      ...(recentMessages?.map?.((m: any) => ({
        role: m?.role === 'user' ? 'user' : 'assistant',
        content: m?.content ?? '',
      })) ?? []),
      { role: 'user', content: message },
    ]

    // Call DeepSeek API with streaming
    const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages,
        stream: true,
        max_tokens: 4000,
        temperature: 0.9,
      }),
    })

    if (!response.ok) {
      const errText = await response.text().catch(() => 'Unknown error')
      console.error('DeepSeek API error:', response.status, errText)
      return new Response(JSON.stringify({ error: `DeepSeek API помилка: ${response.status}` }), { status: 500 })
    }

    // Stream response
    const stream = new ReadableStream({
      async start(controller) {
        const reader = response.body?.getReader()
        const decoder = new TextDecoder()
        const encoder = new TextEncoder()
        let fullContent = ''
        let partialRead = ''

        try {
          while (true) {
            const { done, value } = await reader!.read()
            if (done) break
            partialRead += decoder.decode(value, { stream: true })
            const lines = partialRead.split('\n')
            partialRead = lines.pop() ?? ''

            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const data = line.slice(6).trim()
                if (data === '[DONE]') continue
                try {
                  const parsed = JSON.parse(data)
                  const chunk = parsed?.choices?.[0]?.delta?.content ?? ''
                  if (chunk) {
                    fullContent += chunk
                    controller.enqueue(encoder.encode(`data: ${JSON.stringify({ type: 'chunk', content: chunk })}\n\n`))
                  }
                } catch (e) {
                  // skip invalid JSON
                }
              }
            }
          }

          // Parse all update tags from full content
          const cleanContent = fullContent
          let statUpdate: any = {}
          let relUpdates: any[] = []
          let invUpdates: any[] = []
          let questUpdates: any[] = []
          let diaryUpdates: any[] = []

          // Extract [STAT_UPDATE]...[/STAT_UPDATE]
          const statMatch = cleanContent.match(/\[STAT_UPDATE\](.*?)\[\/STAT_UPDATE\]/s)
          if (statMatch?.[1]) {
            try { statUpdate = JSON.parse(statMatch[1]) } catch (e) {}
          }

          // Extract [REL_UPDATE]...[/REL_UPDATE] (multiple)
          const relMatches = cleanContent.matchAll(/\[REL_UPDATE\](.*?)\[\/REL_UPDATE\]/gs)
          for (const m of relMatches) {
            try {
              const parsed = JSON.parse(m[1])
              if (parsed?.name) relUpdates.push(parsed)
            } catch (e) {}
          }

          // Extract [INV_UPDATE]...[/INV_UPDATE] (multiple)
          const invMatches = cleanContent.matchAll(/\[INV_UPDATE\](.*?)\[\/INV_UPDATE\]/gs)
          for (const m of invMatches) {
            try {
              const parsed = JSON.parse(m[1])
              if (parsed?.name) invUpdates.push(parsed)
            } catch (e) {}
          }

          // Extract [QUEST_UPDATE]...[/QUEST_UPDATE] (multiple)
          const questMatches = cleanContent.matchAll(/\[QUEST_UPDATE\](.*?)\[\/QUEST_UPDATE\]/gs)
          for (const m of questMatches) {
            try {
              const parsed = JSON.parse(m[1])
              if (parsed?.title) questUpdates.push(parsed)
            } catch (e) {}
          }

          // Extract [DIARY_UPDATE]...[/DIARY_UPDATE] (multiple)
          const diaryMatches = cleanContent.matchAll(/\[DIARY_UPDATE\](.*?)\[\/DIARY_UPDATE\]/gs)
          for (const m of diaryMatches) {
            try {
              const parsed = JSON.parse(m[1])
              if (parsed?.content) diaryUpdates.push(parsed)
            } catch (e) {}
          }

          // Extract [SKILL_UPDATE]...[/SKILL_UPDATE] (multiple)
          let skillUpdates: any[] = []
          const skillMatches = cleanContent.matchAll(/\[SKILL_UPDATE\](.*?)\[\/SKILL_UPDATE\]/gs)
          for (const m of skillMatches) {
            try {
              const parsed = JSON.parse(m[1])
              if (parsed?.name && parsed?.xp) skillUpdates.push(parsed)
            } catch (e) {}
          }

          // Remove all tags from display content
          const displayContent = cleanContent
            .replace(/\[STAT_UPDATE\].*?\[\/STAT_UPDATE\]/gs, '')
            .replace(/\[REL_UPDATE\].*?\[\/REL_UPDATE\]/gs, '')
            .replace(/\[INV_UPDATE\].*?\[\/INV_UPDATE\]/gs, '')
            .replace(/\[QUEST_UPDATE\].*?\[\/QUEST_UPDATE\]/gs, '')
            .replace(/\[DIARY_UPDATE\].*?\[\/DIARY_UPDATE\]/gs, '')
            .replace(/\[SKILL_UPDATE\].*?\[\/SKILL_UPDATE\]/gs, '')
            .trim()

          // Save AI message (clean)
          await prisma.message.create({
            data: { role: 'assistant', content: displayContent },
          })

          // Update game state
          if (Object.keys(statUpdate ?? {}).length > 0) {
            const validFields = ['strength','agility','endurance','charisma','willpower','desire','shame','confidence','location','isPregnant','pregnancyWeek','pregnancyFather','amuletEnergy','dayNumber','isDarkLara']
            const updateData: any = {}
            for (const key of validFields) {
              if (statUpdate[key] !== undefined) {
                updateData[key] = statUpdate[key]
              }
            }
            if (Object.keys(updateData).length > 0) {
              await prisma.gameState.update({ where: { id: 'singleton' }, data: updateData })
            }
          }

          // Update relationships
          for (const rel of relUpdates) {
            if (!rel?.name) continue
            await prisma.relationship.upsert({
              where: { name: rel.name },
              update: {
                bond: rel.bond ?? undefined,
                tribe: rel.tribe ?? undefined,
                notes: rel.notes ?? undefined,
                met: rel.met ?? true,
              },
              create: {
                name: rel.name,
                bond: rel.bond ?? 0,
                tribe: rel.tribe ?? '',
                notes: rel.notes ?? '',
                met: rel.met ?? true,
              },
            })
          }

          // Update inventory
          for (const inv of invUpdates) {
            if (!inv?.name) continue
            const action = inv.action ?? 'add'
            if (action === 'add') {
              await prisma.inventoryItem.upsert({
                where: { name: inv.name },
                update: {
                  quantity: { increment: inv.quantity ?? 1 },
                  description: inv.description ?? undefined,
                  category: inv.category ?? undefined,
                },
                create: {
                  name: inv.name,
                  description: inv.description ?? '',
                  quantity: inv.quantity ?? 1,
                  category: inv.category ?? 'misc',
                },
              })
            } else if (action === 'remove') {
              try {
                const existing = await prisma.inventoryItem.findUnique({ where: { name: inv.name } })
                if (existing) {
                  const removeQty = inv.quantity ?? existing.quantity
                  if (existing.quantity <= removeQty) {
                    await prisma.inventoryItem.delete({ where: { name: inv.name } })
                  } else {
                    await prisma.inventoryItem.update({
                      where: { name: inv.name },
                      data: { quantity: { decrement: removeQty } },
                    })
                  }
                }
              } catch (e) { /* item might not exist */ }
            } else if (action === 'update') {
              try {
                await prisma.inventoryItem.update({
                  where: { name: inv.name },
                  data: {
                    description: inv.description ?? undefined,
                    quantity: inv.quantity ?? undefined,
                    category: inv.category ?? undefined,
                  },
                })
              } catch (e) { /* item might not exist */ }
            }
          }

          // Update quests
          for (const q of questUpdates) {
            if (!q?.title) continue
            const action = q.action ?? 'add'
            if (action === 'add') {
              await prisma.quest.upsert({
                where: { title: q.title },
                update: {
                  description: q.description ?? undefined,
                  givenBy: q.givenBy ?? undefined,
                },
                create: {
                  title: q.title,
                  description: q.description ?? '',
                  status: 'active',
                  givenBy: q.givenBy ?? '',
                },
              })
            } else if (action === 'complete') {
              try {
                await prisma.quest.update({
                  where: { title: q.title },
                  data: { status: 'completed' },
                })
              } catch (e) { /* quest might not exist */ }
            } else if (action === 'fail') {
              try {
                await prisma.quest.update({
                  where: { title: q.title },
                  data: { status: 'failed' },
                })
              } catch (e) { /* quest might not exist */ }
            } else if (action === 'update') {
              try {
                await prisma.quest.update({
                  where: { title: q.title },
                  data: {
                    description: q.description ?? undefined,
                    givenBy: q.givenBy ?? undefined,
                  },
                })
              } catch (e) { /* quest might not exist */ }
            }
          }

          // Add diary entries
          const currentDay = gameState?.dayNumber ?? 1
          for (const d of diaryUpdates) {
            if (!d?.content) continue
            await prisma.diaryEntry.create({
              data: {
                title: d.title ?? '',
                content: d.content,
                dayNumber: currentDay,
              },
            })
          }

          // Update skills
          const maxXpByLevel = [100, 150, 225, 350, 500]
          for (const su of skillUpdates) {
            if (!su?.name || !su?.xp) continue
            try {
              const existing = await prisma.skill.findUnique({ where: { name: su.name } })
              if (existing && existing.level < 5) {
                let newXp = existing.xp + su.xp
                let newLevel = existing.level
                let newMaxXp = existing.maxXp
                while (newXp >= newMaxXp && newLevel < 5) {
                  newXp -= newMaxXp
                  newLevel++
                  newMaxXp = maxXpByLevel[Math.min(newLevel, 4)] ?? 500
                }
                if (newLevel >= 5) { newLevel = 5; newXp = 0; newMaxXp = 500 }
                await prisma.skill.update({
                  where: { name: su.name },
                  data: { xp: newXp, level: newLevel, maxXp: newMaxXp },
                })
              }
            } catch (e) { /* skill might not exist */ }
          }

          // Fetch updated state and send final update
          const updatedState = await prisma.gameState.findUnique({ where: { id: 'singleton' } })
          const updatedRels = await prisma.relationship.findMany({ where: { met: true } })
          const updatedInv = await prisma.inventoryItem.findMany()
          const updatedQuests = await prisma.quest.findMany()
          const updatedDiary = await prisma.diaryEntry.findMany({ orderBy: { createdAt: 'desc' }, take: 50 })
          const updatedSkills = await prisma.skill.findMany()

          controller.enqueue(encoder.encode(`data: ${JSON.stringify({
            type: 'done',
            gameState: updatedState,
            relationships: updatedRels,
            inventory: updatedInv,
            quests: updatedQuests,
            diary: updatedDiary,
            skills: updatedSkills,
          })}\n\n`))

        } catch (error: any) {
          console.error('Stream error:', error)
          controller.enqueue(encoder.encode(`data: ${JSON.stringify({ type: 'error', message: error?.message ?? 'Помилка стріму' })}\n\n`))
        } finally {
          controller.close()
        }
      },
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    })
  } catch (error: any) {
    console.error('Chat API error:', error)
    return new Response(JSON.stringify({ error: error?.message ?? 'Внутрішня помилка сервера' }), { status: 500 })
  }
}
