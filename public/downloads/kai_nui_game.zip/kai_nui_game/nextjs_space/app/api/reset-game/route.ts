export const dynamic = "force-dynamic";

import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'

export async function POST() {
  try {
    // Delete all messages
    await prisma.message.deleteMany({})
    // Delete all relationships
    await prisma.relationship.deleteMany({})
    // Delete all inventory
    await prisma.inventoryItem.deleteMany({})
    // Delete all quests
    await prisma.quest.deleteMany({})
    // Delete all diary entries
    await prisma.diaryEntry.deleteMany({})
    // Delete all skills
    await prisma.skill.deleteMany({})
    // Reset game state
    await prisma.gameState.upsert({
      where: { id: 'singleton' },
      update: {
        strength: 6,
        agility: 8,
        endurance: 7,
        charisma: 7,
        willpower: 8,
        desire: 0,
        shame: 0,
        confidence: 50,
        location: 'Берег острова',
        isPregnant: false,
        pregnancyWeek: 0,
        pregnancyFather: null,
        amuletEnergy: 0,
        dayNumber: 1,
        isDarkLara: false,
        gameStarted: true,
      },
      create: {
        id: 'singleton',
        gameStarted: true,
      },
    })

    // Seed initial skills
    const { seedSkills } = await import('@/lib/seed-skills')
    await seedSkills()

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Reset game error:', error)
    return NextResponse.json({ error: error?.message ?? 'Помилка скидання' }, { status: 500 })
  }
}
