'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Send, RotateCcw, Compass, Heart, Shield, Zap, Eye, Brain, Flame, MapPin, Swords, Baby, Gem, ChevronRight, Menu, X, Scroll, Package, BookOpen, Feather, CheckCircle, XCircle, Clock } from 'lucide-react'
import type { GameState, MessageData, RelationshipData, InventoryItemData, QuestData, DiaryEntryData, SkillData } from '@/lib/types'
import { toast } from 'sonner'

type SidebarTab = 'stats' | 'inventory' | 'quests' | 'diary' | 'skills'

const SKILL_CATEGORY_NAMES: Record<string, string> = {
  seduction: '🌹 Зваблення',
  technique: '💋 Техніка',
  endurance: '🔥 Витривалість',
  domination: '⛓️ Домінування',
  submission: '🦋 Підкорення',
  body_magic: '✨ Магія тіла',
}

const INTRO_MESSAGE = `🌊 **Шторм. Темрява. Сіль на губах.**

Останній удар хвилі перевертає човен, і Лара Крафт летить у крижану безодню Тихого океану. Вода б'є в обличчя, ламає дихання, тягне на дно. Рюкзак зі спорядженням — втрачено. Зброя — на дні. Залишився лише стародавній амулет на шиї, який пульсує дивним теплом навіть у крижаній воді.

Хвилі виносять її на берег. Пісок. Теплий, білий пісок. Лара кашляє, випльовуючи солону воду, і відкриває очі.

**Острів.**

Перед нею — стіна тропічних джунглів. Повітря важке, вологе, пахне квітами та чимось... стародавнім. Амулет на грудях теплішає, його символи ледь помітно мерехтять блакитним.

Лара здіймається на ноги. Одяг порваний — від шортів та майки залишились клапті. Тіло подряпане, але нічого не зламано. Босоніж. Без зброї. Без їжі. Без зв'язку із зовнішнім світом.

Тільки амулет. І джунглі попереду.

*Хвилі позаду розбиваються об рифи. Уламки човна розкидані вздовж берега. Десь далеко в джунглях чути барабани...*

**Що робить Лара?**`

export default function GameClient() {
  const [messages, setMessages] = useState<MessageData[]>([])
  const [gameState, setGameState] = useState<GameState | null>(null)
  const [relationships, setRelationships] = useState<RelationshipData[]>([])
  const [inventory, setInventory] = useState<InventoryItemData[]>([])
  const [quests, setQuests] = useState<QuestData[]>([])
  const [diary, setDiary] = useState<DiaryEntryData[]>([])
  const [skills, setSkills] = useState<SkillData[]>([])
  const [input, setInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [streamingContent, setStreamingContent] = useState('')
  const [showSidebar, setShowSidebar] = useState(false)
  const [initialized, setInitialized] = useState(false)
  const [sidebarTab, setSidebarTab] = useState<SidebarTab>('stats')
  const chatEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  const scrollToBottom = useCallback(() => {
    chatEndRef?.current?.scrollIntoView?.({ behavior: 'smooth' })
  }, [])

  useEffect(() => {
    scrollToBottom()
  }, [messages, streamingContent, scrollToBottom])

  useEffect(() => {
    loadGameState()
  }, [])

  const loadGameState = async () => {
    try {
      const res = await fetch('/api/game-state')
      if (!res.ok) throw new Error('Failed to load')
      const data = await res.json()
      setGameState(data?.gameState ?? null)
      setRelationships(data?.relationships ?? [])
      setInventory(data?.inventory ?? [])
      setQuests(data?.quests ?? [])
      setDiary(data?.diary ?? [])
      setSkills(data?.skills ?? [])
      const msgs = data?.messages ?? []
      if (msgs.length === 0) {
        setMessages([{ id: 'intro', role: 'assistant', content: INTRO_MESSAGE, createdAt: new Date().toISOString() }])
      } else {
        setMessages(msgs)
      }
      setInitialized(true)
    } catch (error: any) {
      console.error('Load error:', error)
      setMessages([{ id: 'intro', role: 'assistant', content: INTRO_MESSAGE, createdAt: new Date().toISOString() }])
      setGameState({
        id: 'singleton', strength: 6, agility: 8, endurance: 7, charisma: 7, willpower: 8,
        desire: 0, shame: 0, confidence: 50, location: 'Берег острова',
        isPregnant: false, pregnancyWeek: 0, pregnancyFather: null,
        amuletEnergy: 0, dayNumber: 1, isDarkLara: false, gameStarted: false,
      })
      setInitialized(true)
    }
  }

  const sendMessage = async () => {
    const text = input?.trim?.()
    if (!text || isLoading) return

    const userMsg: MessageData = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text,
      createdAt: new Date().toISOString(),
    }
    setMessages((prev) => [...(prev ?? []), userMsg])
    setInput('')
    setIsLoading(true)
    setStreamingContent('')

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text }),
      })

      if (!res.ok) {
        const err = await res.json().catch(() => ({}))
        throw new Error(err?.error ?? 'Помилка з\'єднання')
      }

      const reader = res.body?.getReader()
      const decoder = new TextDecoder()
      let accumulated = ''
      let partialRead = ''

      while (true) {
        const { done, value } = await reader!.read()
        if (done) break
        partialRead += decoder.decode(value, { stream: true })
        const lines = partialRead.split('\n')
        partialRead = lines.pop() ?? ''

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const dataStr = line.slice(6)
            try {
              const parsed = JSON.parse(dataStr)
              if (parsed?.type === 'chunk') {
                const chunk = parsed?.content ?? ''
                accumulated += chunk
                const display = accumulated
                  .replace(/\[STAT_UPDATE\].*?\[\/STAT_UPDATE\]/gs, '')
                  .replace(/\[REL_UPDATE\].*?\[\/REL_UPDATE\]/gs, '')
                  .replace(/\[INV_UPDATE\].*?\[\/INV_UPDATE\]/gs, '')
                  .replace(/\[QUEST_UPDATE\].*?\[\/QUEST_UPDATE\]/gs, '')
                  .replace(/\[DIARY_UPDATE\].*?\[\/DIARY_UPDATE\]/gs, '')
                  .replace(/\[SKILL_UPDATE\].*?\[\/SKILL_UPDATE\]/gs, '')
                  .replace(/\[STAT_UPDATE\].*/gs, '')
                  .replace(/\[REL_UPDATE\].*/gs, '')
                  .replace(/\[INV_UPDATE\].*/gs, '')
                  .replace(/\[QUEST_UPDATE\].*/gs, '')
                  .replace(/\[DIARY_UPDATE\].*/gs, '')
                  .replace(/\[SKILL_UPDATE\].*/gs, '')
                  .trim()
                setStreamingContent(display)
              } else if (parsed?.type === 'done') {
                if (parsed?.gameState) setGameState(parsed.gameState)
                if (parsed?.relationships) setRelationships(parsed.relationships)
                if (parsed?.inventory) setInventory(parsed.inventory)
                if (parsed?.quests) setQuests(parsed.quests)
                if (parsed?.diary) setDiary(parsed.diary)
                if (parsed?.skills) setSkills(parsed.skills)
              } else if (parsed?.type === 'error') {
                throw new Error(parsed?.message ?? 'Помилка')
              }
            } catch (e: any) {
              // skip invalid JSON
            }
          }
        }
      }

      const finalDisplay = accumulated
        .replace(/\[STAT_UPDATE\].*?\[\/STAT_UPDATE\]/gs, '')
        .replace(/\[REL_UPDATE\].*?\[\/REL_UPDATE\]/gs, '')
        .replace(/\[INV_UPDATE\].*?\[\/INV_UPDATE\]/gs, '')
        .replace(/\[QUEST_UPDATE\].*?\[\/QUEST_UPDATE\]/gs, '')
        .replace(/\[DIARY_UPDATE\].*?\[\/DIARY_UPDATE\]/gs, '')
        .replace(/\[SKILL_UPDATE\].*?\[\/SKILL_UPDATE\]/gs, '')
        .trim()

      const aiMsg: MessageData = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        content: finalDisplay,
        createdAt: new Date().toISOString(),
      }
      setMessages((prev) => [...(prev ?? []), aiMsg])
      setStreamingContent('')

    } catch (error: any) {
      console.error('Send error:', error)
      toast.error(error?.message ?? 'Помилка надсилання')
    } finally {
      setIsLoading(false)
    }
  }

  const resetGame = async () => {
    if (!confirm('Почати нову гру? Весь прогрес буде втрачено!')) return
    try {
      const res = await fetch('/api/reset-game', { method: 'POST' })
      if (!res.ok) throw new Error('Помилка скидання')
      setMessages([{ id: 'intro', role: 'assistant', content: INTRO_MESSAGE, createdAt: new Date().toISOString() }])
      setRelationships([])
      setInventory([])
      setQuests([])
      setDiary([])
      setSkills([])
      // Reload to get seeded skills
      loadGameState()
      setGameState({
        id: 'singleton', strength: 6, agility: 8, endurance: 7, charisma: 7, willpower: 8,
        desire: 0, shame: 0, confidence: 50, location: 'Берег острова',
        isPregnant: false, pregnancyWeek: 0, pregnancyFather: null,
        amuletEnergy: 0, dayNumber: 1, isDarkLara: false, gameStarted: true,
      })
      toast.success('Нову гру розпочато!')
    } catch (error: any) {
      console.error('Reset error:', error)
      toast.error('Помилка скидання гри')
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  const formatMessage = (content: string) => {
    if (!content) return ''
    return content
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/\n/g, '<br/>')
  }

  const getDesireColor = (desire: number) => {
    const d = desire ?? 0
    if (d <= 15) return 'bg-sky-500'
    if (d <= 35) return 'bg-emerald-500'
    if (d <= 55) return 'bg-yellow-500'
    if (d <= 75) return 'bg-orange-500'
    if (d <= 90) return 'bg-red-500'
    return 'bg-red-700 animate-pulse'
  }

  const getDesireLabel = (desire: number) => {
    const d = desire ?? 0
    if (d <= 15) return 'Спокій'
    if (d <= 35) return 'Цікавість'
    if (d <= 55) return 'Збудження'
    if (d <= 75) return 'Жага'
    if (d <= 90) return 'Голод'
    return 'Шаленство'
  }

  const getCategoryIcon = (cat: string) => {
    switch (cat) {
      case 'зброя': return '\u2694\ufe0f'
      case 'їжа': return '\ud83c\udf56'
      case 'ресурс': return '\ud83e\udea8'
      case 'одяг': return '\ud83d\udc58'
      case 'артефакт': return '\ud83d\udd2e'
      case 'інструмент': return '\ud83d\udd27'
      default: return '\ud83d\udce6'
    }
  }

  const StatBar = ({ label, value, max, icon, color }: { label: string; value: number; max: number; icon: React.ReactNode; color: string }) => (
    <div className="flex items-center gap-2">
      <div className="text-muted-foreground w-5 flex-shrink-0">{icon}</div>
      <div className="flex-1 min-w-0">
        <div className="flex justify-between text-xs mb-0.5">
          <span className="text-foreground/80">{label}</span>
          <span className="font-mono text-foreground/60">{value ?? 0}/{max}</span>
        </div>
        <div className="h-1.5 bg-muted rounded-full overflow-hidden">
          <motion.div
            className={`h-full rounded-full ${color}`}
            initial={{ width: 0 }}
            animate={{ width: `${((value ?? 0) / max) * 100}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
      </div>
    </div>
  )

  const activeQuests = quests.filter(q => q.status === 'active')
  const completedQuests = quests.filter(q => q.status === 'completed')
  const failedQuests = quests.filter(q => q.status === 'failed')

  if (!initialized) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
          className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full"
        />
      </div>
    )
  }

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-border bg-card/80 backdrop-blur-sm">
        <div className="flex items-center justify-between px-4 h-14">
          <div className="flex items-center gap-3">
            <Compass className="w-6 h-6 text-primary" />
            <div>
              <h1 className="font-display text-base font-bold tracking-tight text-foreground">Острів Кай-Нуї</h1>
              <p className="text-[10px] text-muted-foreground">День {gameState?.dayNumber ?? 1} • {gameState?.location ?? 'Невідомо'}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={resetGame}
              className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
              title="Нова гра"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={() => setShowSidebar(!showSidebar)}
              className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground lg:hidden"
            >
              {showSidebar ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* Main content */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Chat area */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto chat-scroll px-4 py-4 space-y-4">
            <AnimatePresence initial={false}>
              {(messages ?? []).map((msg: MessageData, index: number) => (
                <motion.div
                  key={msg?.id ?? index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  className={`flex ${msg?.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] md:max-w-[75%] rounded-2xl px-4 py-3 ${
                      msg?.role === 'user'
                        ? 'bg-primary text-primary-foreground rounded-br-sm'
                        : 'bg-card border border-border rounded-bl-sm'
                    }`}
                  >
                    {msg?.role === 'assistant' && (
                      <div className="flex items-center gap-1.5 mb-2">
                        <Scroll className="w-3.5 h-3.5 text-primary" />
                        <span className="text-xs font-medium text-primary">Майстер Гри</span>
                      </div>
                    )}
                    <div
                      className="text-sm leading-relaxed whitespace-pre-wrap"
                      dangerouslySetInnerHTML={{ __html: formatMessage(msg?.content ?? '') }}
                    />
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {/* Streaming content */}
            {streamingContent && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex justify-start"
              >
                <div className="max-w-[85%] md:max-w-[75%] rounded-2xl px-4 py-3 bg-card border border-border rounded-bl-sm">
                  <div className="flex items-center gap-1.5 mb-2">
                    <Scroll className="w-3.5 h-3.5 text-primary" />
                    <span className="text-xs font-medium text-primary">Майстер Гри</span>
                  </div>
                  <div
                    className="text-sm leading-relaxed whitespace-pre-wrap typing-cursor"
                    dangerouslySetInnerHTML={{ __html: formatMessage(streamingContent) }}
                  />
                </div>
              </motion.div>
            )}

            {/* Loading indicator */}
            {isLoading && !streamingContent && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex justify-start"
              >
                <div className="bg-card border border-border rounded-2xl rounded-bl-sm px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="flex gap-1">
                      {[0, 1, 2].map((i) => (
                        <motion.div
                          key={i}
                          className="w-2 h-2 bg-primary rounded-full"
                          animate={{ y: [0, -6, 0] }}
                          transition={{ duration: 0.6, delay: i * 0.15, repeat: Infinity }}
                        />
                      ))}
                    </div>
                    <span className="text-xs text-muted-foreground">Майстер обдумує...</span>
                  </div>
                </div>
              </motion.div>
            )}

            <div ref={chatEndRef} />
          </div>

          {/* Input area */}
          <div className="flex-shrink-0 border-t border-border bg-card/50 backdrop-blur-sm p-4">
            <div className="flex gap-2 items-end max-w-3xl mx-auto">
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e?.target?.value ?? '')}
                onKeyDown={handleKeyDown}
                placeholder="Що робить Лара?..."
                className="flex-1 resize-none bg-muted/50 border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all min-h-[44px] max-h-[120px] text-foreground placeholder:text-muted-foreground"
                rows={1}
                disabled={isLoading}
                onInput={(e: React.FormEvent<HTMLTextAreaElement>) => {
                  const target = e?.currentTarget
                  if (target) {
                    target.style.height = 'auto'
                    target.style.height = Math.min(target.scrollHeight, 120) + 'px'
                  }
                }}
              />
              <button
                onClick={sendMessage}
                disabled={isLoading || !(input?.trim?.())}
                className="flex-shrink-0 p-3 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <aside
          className={`${
            showSidebar ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
          } absolute lg:relative right-0 top-0 h-full w-72 xl:w-80 border-l border-border bg-card overflow-hidden transition-transform duration-300 z-20 flex flex-col`}
        >
          {/* Sidebar Tabs */}
          <div className="flex-shrink-0 border-b border-border">
            <div className="flex">
              {[
                { id: 'stats' as SidebarTab, icon: <Shield className="w-3.5 h-3.5" />, label: 'Стати' },
                { id: 'inventory' as SidebarTab, icon: <Package className="w-3.5 h-3.5" />, label: 'Інвентар' },
                { id: 'quests' as SidebarTab, icon: <BookOpen className="w-3.5 h-3.5" />, label: 'Квести' },
                { id: 'diary' as SidebarTab, icon: <Feather className="w-3.5 h-3.5" />, label: 'Щоденник' },
                { id: 'skills' as SidebarTab, icon: <Flame className="w-3.5 h-3.5" />, label: 'Навички' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setSidebarTab(tab.id)}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 text-[11px] font-medium transition-colors border-b-2 ${
                    sidebarTab === tab.id
                      ? 'border-primary text-primary'
                      : 'border-transparent text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {tab.icon}
                  <span className="hidden xl:inline">{tab.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Sidebar Content */}
          <div className="flex-1 overflow-y-auto chat-scroll p-4">
            {/* STATS TAB */}
            {sidebarTab === 'stats' && (
              <div className="space-y-5">
                {/* Desire */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Flame className="w-4 h-4 text-red-400" />
                      <span className="text-sm font-medium">Бажання</span>
                    </div>
                    <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                      {getDesireLabel(gameState?.desire ?? 0)}
                    </span>
                  </div>
                  <div className="h-3 bg-muted rounded-full overflow-hidden">
                    <motion.div
                      className={`h-full rounded-full ${getDesireColor(gameState?.desire ?? 0)}`}
                      animate={{ width: `${gameState?.desire ?? 0}%` }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                  <div className="text-right text-xs font-mono text-muted-foreground">{gameState?.desire ?? 0}/100</div>
                </div>

                {/* Stats */}
                <div className="space-y-3">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Характеристики</h3>
                  <StatBar label="Сила" value={gameState?.strength ?? 6} max={10} icon={<Swords className="w-4 h-4" />} color="bg-red-500" />
                  <StatBar label="Спритність" value={gameState?.agility ?? 8} max={10} icon={<Zap className="w-4 h-4" />} color="bg-emerald-500" />
                  <StatBar label="Витривалість" value={gameState?.endurance ?? 7} max={10} icon={<Shield className="w-4 h-4" />} color="bg-amber-500" />
                  <StatBar label="Харизма" value={gameState?.charisma ?? 7} max={10} icon={<Heart className="w-4 h-4" />} color="bg-pink-500" />
                  <StatBar label="Воля" value={gameState?.willpower ?? 8} max={10} icon={<Brain className="w-4 h-4" />} color="bg-violet-500" />
                </div>

                {/* Extra stats */}
                <div className="space-y-3">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Стан</h3>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="bg-muted/50 rounded-lg p-2.5">
                      <div className="flex items-center gap-1.5 mb-1">
                        <Eye className="w-3.5 h-3.5 text-muted-foreground" />
                        <span className="text-[10px] text-muted-foreground">Сором</span>
                      </div>
                      <span className="text-sm font-mono font-bold">{gameState?.shame ?? 0}</span>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-2.5">
                      <div className="flex items-center gap-1.5 mb-1">
                        <ChevronRight className="w-3.5 h-3.5 text-muted-foreground" />
                        <span className="text-[10px] text-muted-foreground">Впевненість</span>
                      </div>
                      <span className="text-sm font-mono font-bold">{gameState?.confidence ?? 50}</span>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-2.5">
                      <div className="flex items-center gap-1.5 mb-1">
                        <Gem className="w-3.5 h-3.5 text-primary" />
                        <span className="text-[10px] text-muted-foreground">Амулет</span>
                      </div>
                      <span className="text-sm font-mono font-bold text-primary">{gameState?.amuletEnergy ?? 0}</span>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-2.5">
                      <div className="flex items-center gap-1.5 mb-1">
                        <MapPin className="w-3.5 h-3.5 text-muted-foreground" />
                        <span className="text-[10px] text-muted-foreground">День</span>
                      </div>
                      <span className="text-sm font-mono font-bold">{gameState?.dayNumber ?? 1}</span>
                    </div>
                  </div>
                </div>

                {/* Location */}
                <div className="bg-muted/30 rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-1">
                    <MapPin className="w-4 h-4 text-primary" />
                    <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Локація</span>
                  </div>
                  <p className="text-sm font-medium">{gameState?.location ?? 'Невідомо'}</p>
                </div>

                {/* Pregnancy */}
                {gameState?.isPregnant && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-pink-500/10 border border-pink-500/30 rounded-lg p-3"
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Baby className="w-4 h-4 text-pink-400" />
                      <span className="text-xs font-semibold text-pink-400">Вагітність</span>
                    </div>
                    <p className="text-sm">Тиждень {gameState?.pregnancyWeek ?? 0}/6</p>
                    {gameState?.pregnancyFather && (
                      <p className="text-xs text-muted-foreground">Батько: {gameState.pregnancyFather}</p>
                    )}
                  </motion.div>
                )}

                {/* Relationships */}
                {(relationships?.length ?? 0) > 0 && (
                  <div className="space-y-2">
                    <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Стосунки</h3>
                    {(relationships ?? []).map((rel: RelationshipData) => (
                      <div key={rel?.id ?? rel?.name} className="bg-muted/30 rounded-lg p-2.5">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-sm font-medium">{rel?.name ?? '???'}</span>
                          <span className="text-xs font-mono text-muted-foreground">
                            {rel?.bond ?? 0}/10
                          </span>
                        </div>
                        {rel?.tribe && (
                          <span className="text-[10px] text-muted-foreground">{rel.tribe}</span>
                        )}
                        <div className="h-1 bg-muted rounded-full mt-1 overflow-hidden">
                          <div
                            className="h-full bg-pink-500 rounded-full transition-all duration-500"
                            style={{ width: `${((rel?.bond ?? 0) / 10) * 100}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* INVENTORY TAB */}
            {sidebarTab === 'inventory' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Інвентар</h3>
                  <span className="text-[10px] text-muted-foreground font-mono">{inventory.length} предм.</span>
                </div>
                {inventory.length === 0 ? (
                  <div className="text-center py-8">
                    <Package className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
                    <p className="text-sm text-muted-foreground">Інвентар порожній</p>
                    <p className="text-xs text-muted-foreground/60 mt-1">Знайдіть предмети на острові</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {inventory.map((item: InventoryItemData) => (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="bg-muted/30 rounded-lg p-3 border border-border/50"
                      >
                        <div className="flex items-start gap-2">
                          <span className="text-lg flex-shrink-0">{getCategoryIcon(item.category)}</span>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <span className="text-sm font-medium truncate">{item.name}</span>
                              {item.quantity > 1 && (
                                <span className="text-xs font-mono bg-primary/20 text-primary px-1.5 py-0.5 rounded-full ml-2 flex-shrink-0">
                                  x{item.quantity}
                                </span>
                              )}
                            </div>
                            {item.description && (
                              <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{item.description}</p>
                            )}
                            <span className="text-[10px] text-muted-foreground/60 capitalize">{item.category}</span>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* QUESTS TAB */}
            {sidebarTab === 'quests' && (
              <div className="space-y-4">
                {/* Active quests */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-amber-400" />
                    <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Активні</h3>
                    {activeQuests.length > 0 && (
                      <span className="text-[10px] font-mono bg-amber-500/20 text-amber-400 px-1.5 py-0.5 rounded-full">{activeQuests.length}</span>
                    )}
                  </div>
                  {activeQuests.length === 0 ? (
                    <div className="text-center py-6">
                      <BookOpen className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
                      <p className="text-xs text-muted-foreground">Немає активних квестів</p>
                    </div>
                  ) : (
                    activeQuests.map((q: QuestData) => (
                      <motion.div
                        key={q.id}
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="bg-amber-500/5 border border-amber-500/20 rounded-lg p-3"
                      >
                        <div className="flex items-start gap-2">
                          <span className="text-base flex-shrink-0 mt-0.5">\u23f3</span>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium">{q.title}</p>
                            {q.description && (
                              <p className="text-xs text-muted-foreground mt-0.5">{q.description}</p>
                            )}
                            {q.givenBy && (
                              <p className="text-[10px] text-muted-foreground/60 mt-1">Від: {q.givenBy}</p>
                            )}
                          </div>
                        </div>
                      </motion.div>
                    ))
                  )}
                </div>

                {/* Completed quests */}
                {completedQuests.length > 0 && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                      <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Завершені</h3>
                      <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded-full">{completedQuests.length}</span>
                    </div>
                    {completedQuests.map((q: QuestData) => (
                      <div key={q.id} className="bg-emerald-500/5 border border-emerald-500/20 rounded-lg p-2.5 opacity-80">
                        <div className="flex items-center gap-2">
                          <span className="text-sm">\u2705</span>
                          <div className="min-w-0">
                            <p className="text-xs font-medium line-through text-muted-foreground">{q.title}</p>
                            {q.givenBy && <p className="text-[10px] text-muted-foreground/50">Від: {q.givenBy}</p>}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Failed quests */}
                {failedQuests.length > 0 && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <XCircle className="w-3.5 h-3.5 text-red-400" />
                      <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Провалені</h3>
                    </div>
                    {failedQuests.map((q: QuestData) => (
                      <div key={q.id} className="bg-red-500/5 border border-red-500/20 rounded-lg p-2.5 opacity-60">
                        <div className="flex items-center gap-2">
                          <span className="text-sm">\u274c</span>
                          <p className="text-xs font-medium line-through text-muted-foreground">{q.title}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* DIARY TAB */}
            {sidebarTab === 'diary' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Щоденник Лари</h3>
                  <span className="text-[10px] text-muted-foreground font-mono">{diary.length} зап.</span>
                </div>
                {diary.length === 0 ? (
                  <div className="text-center py-8">
                    <Feather className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
                    <p className="text-sm text-muted-foreground">Щоденник порожній</p>
                    <p className="text-xs text-muted-foreground/60 mt-1">Записи з'являться після важливих подій</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {diary.map((entry: DiaryEntryData) => (
                      <motion.div
                        key={entry.id}
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="bg-muted/30 rounded-lg p-3 border border-border/50"
                      >
                        <div className="flex items-center justify-between mb-1.5">
                          {entry.title ? (
                            <span className="text-xs font-semibold text-primary">{entry.title}</span>
                          ) : (
                            <span className="text-xs font-semibold text-primary">Запис</span>
                          )}
                          <span className="text-[10px] font-mono text-muted-foreground/60">День {entry.dayNumber}</span>
                        </div>
                        <p className="text-xs text-foreground/80 leading-relaxed whitespace-pre-wrap">{entry.content}</p>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* SKILLS TAB */}
            {sidebarTab === 'skills' && (
              <div className="space-y-4">
                {Object.entries(SKILL_CATEGORY_NAMES).map(([cat, catName]) => {
                  const catSkills = skills.filter((s: SkillData) => s.category === cat)
                  if (catSkills.length === 0) return null
                  return (
                    <div key={cat} className="space-y-2">
                      <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{catName}</h4>
                      {catSkills.map((skill: SkillData) => (
                        <div key={skill.id} className="bg-muted/30 rounded-lg p-2.5 border border-border/50">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs font-medium text-foreground">{skill.name}</span>
                            <span className="text-[10px] font-mono text-primary">Рів. {skill.level}</span>
                          </div>
                          <p className="text-[10px] text-muted-foreground mb-1.5">{skill.description}</p>
                          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-pink-500 to-rose-400 rounded-full transition-all duration-500"
                              style={{ width: `${skill.maxXp > 0 ? (skill.xp / skill.maxXp) * 100 : 0}%` }}
                            />
                          </div>
                          <div className="flex justify-end mt-0.5">
                            <span className="text-[9px] font-mono text-muted-foreground/60">{skill.xp}/{skill.maxXp} XP</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )
                })}
                {skills.length === 0 && (
                  <div className="text-center py-8">
                    <Flame className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
                    <p className="text-sm text-muted-foreground">Навичок поки немає</p>
                    <p className="text-xs text-muted-foreground/60 mt-1">Вони з'являться під час інтимних сцен</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </aside>

        {/* Overlay for mobile sidebar */}
        {showSidebar && (
          <div
            className="fixed inset-0 bg-black/50 z-10 lg:hidden"
            onClick={() => setShowSidebar(false)}
          />
        )}
      </div>
    </div>
  )
}
